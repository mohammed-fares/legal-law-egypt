import { useGetDashboardStats, useGetRecentCases, useGetCaseTypeCounts, getGetDashboardStatsQueryKey, getGetRecentCasesQueryKey, getGetCaseTypeCountsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { FileText, Clock, CheckCircle, Calendar, Activity, AlertCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useGetDashboardStats({
    query: { queryKey: getGetDashboardStatsQueryKey() }
  });
  
  const { data: recentCases, isLoading: casesLoading } = useGetRecentCases({
    query: { queryKey: getGetRecentCasesQueryKey() }
  });
  
  const { data: typeCounts, isLoading: typesLoading } = useGetCaseTypeCounts({
    query: { queryKey: getGetCaseTypeCountsQueryKey() }
  });

  const translateCaseType = (type: string) => {
    const map: Record<string, string> = {
      civil: "مدني",
      criminal: "جنائي",
      commercial: "تجاري",
      administrative: "إداري",
      labor: "عمالي",
      personal: "أحوال",
      realestate: "عقاري",
      intellectual: "ملكية فكرية"
    };
    return map[type] || type;
  };

  const chartData = typeCounts?.map(tc => ({
    name: translateCaseType(tc.type),
    count: tc.count
  })) || [];

  return (
    <div className="space-y-6 pb-8">
      <div>
        <h1 className="text-2xl font-bold mb-1">لوحة التحكم</h1>
        <p className="text-muted-foreground">نظرة عامة على نشاطك القانوني</p>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">إجمالي القضايا</CardTitle>
            <FileText className="w-4 h-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statsLoading ? "..." : stats?.totalCases || 0}</div>
          </CardContent>
        </Card>
        
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">قضايا نشطة</CardTitle>
            <Activity className="w-4 h-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statsLoading ? "..." : stats?.activeCases || 0}</div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">تحليلات مكتملة</CardTitle>
            <CheckCircle className="w-4 h-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statsLoading ? "..." : stats?.completedAnalysis || 0}</div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">جلسات قادمة</CardTitle>
            <Calendar className="w-4 h-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statsLoading ? "..." : stats?.upcomingSessions || 0}</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart */}
        <Card className="lg:col-span-2 border-border">
          <CardHeader>
            <CardTitle>توزيع القضايا حسب النوع</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] w-full">
              {typesLoading ? (
                <div className="w-full h-full flex items-center justify-center text-muted-foreground">جاري التحميل...</div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                    <XAxis 
                      dataKey="name" 
                      stroke="#888888" 
                      fontSize={12}
                      tickLine={false}
                      axisLine={false}
                    />
                    <YAxis 
                      stroke="#888888" 
                      fontSize={12}
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={(value) => `${value}`}
                    />
                    <Tooltip 
                      cursor={{fill: 'transparent'}}
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))' }}
                    />
                    <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill="hsl(var(--primary))" />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Notifications / Updates */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle>تحديثات هامة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex gap-3 items-start border-b border-border/50 pb-3">
                <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center shrink-0">
                  <AlertCircle className="w-4 h-4 text-blue-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">تم اكتمال تحليل قضية "النزاع العقاري المرج"</p>
                  <p className="text-xs text-muted-foreground mt-1">منذ ساعتين</p>
                </div>
              </div>
              <div className="flex gap-3 items-start border-b border-border/50 pb-3">
                <div className="w-8 h-8 rounded-full bg-orange-500/10 flex items-center justify-center shrink-0">
                  <Clock className="w-4 h-4 text-orange-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">تذكير: جلسة محكمة الأسرة غداً 9:00 صباحاً</p>
                  <p className="text-xs text-muted-foreground mt-1">منذ 5 ساعات</p>
                </div>
              </div>
              <div className="flex gap-3 items-start">
                <div className="w-8 h-8 rounded-full bg-green-500/10 flex items-center justify-center shrink-0">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">مستندات القضية العمالية تم قبولها</p>
                  <p className="text-xs text-muted-foreground mt-1">أمس</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Cases */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle>أحدث القضايا</CardTitle>
        </CardHeader>
        <CardContent>
          {casesLoading ? (
            <div className="text-center py-4 text-muted-foreground">جاري التحميل...</div>
          ) : recentCases && recentCases.length > 0 ? (
            <div className="space-y-4">
              {recentCases.map(c => (
                <div key={c.id} className="flex items-center justify-between p-4 rounded-lg bg-secondary/30 border border-border">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <FileText className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium">{c.title}</h4>
                      <p className="text-sm text-muted-foreground flex items-center gap-2 mt-1">
                        <span>{translateCaseType(c.type)}</span>
                        <span>•</span>
                        <span>{c.court || "لم يحدد محكمة"}</span>
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <Badge variant={c.status === 'active' ? 'default' : 'secondary'} className="font-normal">
                      {c.status === 'active' ? 'نشطة' : c.status === 'pending' ? 'قيد الانتظار' : 'مغلقة'}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {format(new Date(c.date), 'd MMMM yyyy', { locale: ar })}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">لا توجد قضايا حديثة</div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
