import { useState } from "react";
import { Link } from "wouter";
import { useGetCases, getGetCasesQueryKey, useDeleteCase } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Search, Plus, MoreVertical, Eye, FileEdit, Trash2, Shield, Brain } from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

export default function CasesList() {
  const [search, setSearch] = useState("");
  const [type, setType] = useState<string>("");
  const [status, setStatus] = useState<string>("");
  
  const queryClient = useQueryClient();

  const { data: cases, isLoading } = useGetCases(
    { search, type: type === "all" ? undefined : type, status: status === "all" ? undefined : status },
    { query: { queryKey: getGetCasesQueryKey({ search, type: type === "all" ? undefined : type, status: status === "all" ? undefined : status }) } }
  );

  const deleteCaseMutation = useDeleteCase();

  const handleDelete = (id: number) => {
    if (confirm("هل أنت متأكد من حذف هذه القضية؟")) {
      deleteCaseMutation.mutate({ id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetCasesQueryKey() });
        }
      });
    }
  };

  const translateType = (t: string) => {
    const map: Record<string, string> = {
      civil: "مدني", criminal: "جنائي", commercial: "تجاري", 
      administrative: "إداري", labor: "عمالي", personal: "أحوال شخصية", 
      realestate: "عقاري", intellectual: "ملكية فكرية"
    };
    return map[t] || t;
  };

  return (
    <div className="space-y-6 pb-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold mb-1">ملفات القضايا</h1>
          <p className="text-muted-foreground">إدارة وتتبع جميع قضاياك</p>
        </div>
        <Link href="/cases/new">
          <Button className="shrink-0 gap-2">
            <Plus className="w-4 h-4" />
            إضافة قضية
          </Button>
        </Link>
      </div>

      <Card className="border-border">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="ابحث برقم القضية، العنوان، أو المحكمة..." 
                className="pl-3 pr-10"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <div className="flex gap-4 w-full md:w-auto">
              <Select value={type} onValueChange={setType}>
                <SelectTrigger className="w-full md:w-[160px]">
                  <SelectValue placeholder="نوع القضية" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">الكل</SelectItem>
                  <SelectItem value="civil">مدني</SelectItem>
                  <SelectItem value="criminal">جنائي</SelectItem>
                  <SelectItem value="commercial">تجاري</SelectItem>
                  <SelectItem value="labor">عمالي</SelectItem>
                  <SelectItem value="personal">أحوال شخصية</SelectItem>
                </SelectContent>
              </Select>
              <Select value={status} onValueChange={setStatus}>
                <SelectTrigger className="w-full md:w-[140px]">
                  <SelectValue placeholder="الحالة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">الكل</SelectItem>
                  <SelectItem value="active">نشطة</SelectItem>
                  <SelectItem value="pending">قيد الانتظار</SelectItem>
                  <SelectItem value="closed">مغلقة</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-secondary/50">
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="text-right">رقم القضية</TableHead>
                <TableHead className="text-right">العنوان</TableHead>
                <TableHead className="text-right">النوع</TableHead>
                <TableHead className="text-right">المحكمة</TableHead>
                <TableHead className="text-right">التاريخ</TableHead>
                <TableHead className="text-right">الحالة</TableHead>
                <TableHead className="text-right">الذكاء الاصطناعي</TableHead>
                <TableHead className="w-[80px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center h-32 text-muted-foreground">
                    جاري التحميل...
                  </TableCell>
                </TableRow>
              ) : cases && cases.length > 0 ? (
                cases.map((c) => (
                  <TableRow key={c.id} className="border-border">
                    <TableCell className="font-mono text-xs">{c.caseNumber}</TableCell>
                    <TableCell className="font-medium max-w-[200px] truncate" title={c.title}>
                      {c.title}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="font-normal bg-background">
                        {translateType(c.type)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm max-w-[150px] truncate" title={c.court || ""}>
                      {c.court || "-"}
                    </TableCell>
                    <TableCell className="text-sm">
                      {format(new Date(c.date), 'dd/MM/yyyy')}
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={c.status === 'active' ? 'default' : c.status === 'closed' ? 'outline' : 'secondary'}
                        className="font-normal"
                      >
                        {c.status === 'active' ? 'نشطة' : c.status === 'pending' ? 'انتظار' : 'مغلقة'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {c.analysisStatus === 'completed' ? (
                        <div className="flex items-center gap-1.5 text-primary text-sm font-medium">
                          <Brain className="w-4 h-4" />
                          <span>محللة</span>
                        </div>
                      ) : (
                        <span className="text-xs text-muted-foreground">لم تحلل</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-[160px]">
                          <DropdownMenuItem className="cursor-pointer">
                            <Eye className="w-4 h-4 ml-2" />
                            عرض التفاصيل
                          </DropdownMenuItem>
                          <DropdownMenuItem className="cursor-pointer">
                            <FileEdit className="w-4 h-4 ml-2" />
                            تعديل
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            className="cursor-pointer text-destructive focus:bg-destructive/10 focus:text-destructive"
                            onClick={() => handleDelete(c.id)}
                          >
                            <Trash2 className="w-4 h-4 ml-2" />
                            حذف
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={8} className="text-center h-32 text-muted-foreground">
                    لا توجد قضايا مطابقة للبحث
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}
