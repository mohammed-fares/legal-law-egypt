import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  FolderOpen,
  Users,
  MessageSquare,
  BookOpen,
  LogOut,
  Search,
  Bell,
} from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { name, role, logout } = useAuth();

  const navItems = [
    { href: "/dashboard", label: "لوحة التحكم", icon: LayoutDashboard },
    { href: "/cases", label: "القضايا", icon: FolderOpen },
    { href: "/lawyers", label: "المحامين", icon: Users },
    { href: "/chat", label: "المحادثات", icon: MessageSquare },
    { href: "/library", label: "المكتبة القانونية", icon: BookOpen },
  ];

  return (
    <div
      className="flex h-screen w-full bg-background text-foreground overflow-hidden"
      dir="rtl"
    >
      {/* Sidebar */}
      <aside className="w-64 border-l border-border bg-card flex flex-col">
        <div className="p-6 border-b border-border flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-primary flex items-center justify-center">
            <span className="text-primary-foreground font-bold font-serif text-xl">
              ق
            </span>
          </div>
          <div>
            <h1 className="font-bold text-lg leading-tight">القانوني المصري</h1>
            <p className="text-xs text-muted-foreground mt-[8px]">
              {role === "lawyer" ? "بوابة المحامين" : "بوابة المواطنين"}
            </p>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.startsWith(item.href);
            return (
              <Link key={item.href} href={item.href} className="block">
                <span
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-md transition-colors text-sm font-medium",
                    isActive
                      ? "bg-primary/10 text-primary"
                      : "text-muted-foreground hover:bg-muted hover:text-foreground",
                  )}
                >
                  <Icon className="w-5 h-5" />
                  {item.label}
                </span>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-border">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center border border-border">
              <span className="font-bold text-sm">{name.charAt(0)}</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{name}</p>
              <p className="text-xs text-muted-foreground truncate mt-[3px]">
                {role === "lawyer" ? "محامي" : "مواطن"}
              </p>
            </div>
          </div>
          <Button
            variant="outline"
            className="w-full justify-start text-muted-foreground"
            onClick={logout}
          >
            <LogOut className="w-4 h-4 mr-2 ml-2" />
            تسجيل الخروج
          </Button>
        </div>
      </aside>
      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        <header className="h-16 border-b border-border bg-card flex px-6 shrink-0 text-left flex-row justify-end items-center">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-primary" />
            </Button>
            <Link href="/cases/new">
              <Button size="sm">قضية جديدة +</Button>
            </Link>
          </div>
        </header>
        <div className="flex-1 overflow-auto bg-background p-6">
          <div className="max-w-6xl mx-auto h-full">{children}</div>
        </div>
      </main>
    </div>
  );
}
