import { Router } from "express";
import { db } from "@workspace/db";
import { casesTable } from "@workspace/db";
import { eq, sql, desc } from "drizzle-orm";

const router = Router();

router.get("/dashboard/stats", async (req, res) => {
  try {
    const [total] = await db.select({ count: sql<number>`count(*)` }).from(casesTable);
    const [active] = await db.select({ count: sql<number>`count(*)` }).from(casesTable).where(eq(casesTable.status, "active"));
    const [completed] = await db.select({ count: sql<number>`count(*)` }).from(casesTable).where(eq(casesTable.analysisStatus, "completed"));

    res.json({
      totalCases: Number(total?.count ?? 0),
      activeCases: Number(active?.count ?? 0),
      completedAnalysis: Number(completed?.count ?? 0),
      upcomingSessions: 3,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/dashboard/recent-cases", async (req, res) => {
  try {
    const cases = await db.select().from(casesTable).orderBy(desc(casesTable.id)).limit(5);
    res.json(cases.map((c) => ({
      id: c.id,
      caseNumber: c.caseNumber,
      type: c.type,
      title: c.title,
      description: c.description ?? null,
      court: c.court ?? null,
      courtCaseNumber: c.courtCaseNumber ?? null,
      status: c.status,
      date: c.createdAt.toISOString().split("T")[0],
      analysisStatus: c.analysisStatus,
    })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/dashboard/case-type-counts", async (req, res) => {
  try {
    const counts = await db.select({
      type: casesTable.type,
      count: sql<number>`count(*)`,
    }).from(casesTable).groupBy(casesTable.type);

    res.json(counts.map((r) => ({ type: r.type, count: Number(r.count) })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
