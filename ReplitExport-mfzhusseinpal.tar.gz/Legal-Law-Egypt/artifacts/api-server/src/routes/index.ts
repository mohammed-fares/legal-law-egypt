import { Router, type IRouter } from "express";
import healthRouter from "./health";
import casesRouter from "./cases";
import lawyersRouter from "./lawyers";
import messagesRouter from "./messages";
import dashboardRouter from "./dashboard";
import anthropicRouter from "./anthropic/index";

const router: IRouter = Router();

router.use(healthRouter);
router.use(casesRouter);
router.use(lawyersRouter);
router.use(messagesRouter);
router.use(dashboardRouter);
router.use(anthropicRouter);

export default router;
