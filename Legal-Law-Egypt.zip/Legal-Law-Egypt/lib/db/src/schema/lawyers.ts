import { pgTable, text, serial, integer, boolean, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const lawyersTable = pgTable("lawyers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  specialty: text("specialty").notNull(),
  branch: text("branch").notNull(),
  experience: text("experience").notNull(),
  rating: real("rating").notNull().default(4.5),
  casesCount: integer("cases_count").notNull().default(0),
  online: boolean("online").notNull().default(false),
  initials: text("initials").notNull(),
});

export const insertLawyerSchema = createInsertSchema(lawyersTable).omit({ id: true });
export type InsertLawyer = z.infer<typeof insertLawyerSchema>;
export type Lawyer = typeof lawyersTable.$inferSelect;
