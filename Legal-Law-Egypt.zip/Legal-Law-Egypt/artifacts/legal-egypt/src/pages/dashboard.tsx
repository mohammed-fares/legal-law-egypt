import { useGetDashboardStats, useGetRecentCases, useGetCaseTypeCounts, getGetDashboardStatsQueryKey, getGetRecentCasesQueryKey, getGetCaseTypeCountsQueryKey } from "@workspace/api-client-react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { FileText, Clock, CheckCircle, Calendar, Activity, AlertCircle, Bell } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

interface Notification {
  id: string;
  type: string;
  message: string;
  time: string;
}

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useGetDashboardStats({
    query: { queryKey: getGetDashboardStatsQueryKey() }
  });
  
  const { data: recentCases, isLoading: casesLoading } = useGetRecentCases({
    query: { queryKey: getGetRecentCasesQueryKey() }
  });
  
  const { data: typeCounts, isLoading: typesLoading } = useGetCaseTypeCounts({
    query: { queryKey: getGetCaseTypeCountsQueryKey() }
  });

  const { data: notifications, isLoading: notificationsLoading } = useQuery<Notification[]>({
    queryKey: ["dashboard-notifications"],
    queryFn: async () => {
      const res = await fetch("/api/dashboard/notifications");
      if (!res.ok) throw new Error("Failed to fetch notifications");
      return res.json();
    },
    refetchInterval: 30000,
  });

  const translateCaseType = (type: string) => {
    const map: Record<string, string> = {
      civil: "مدني",
      criminal: "جنائي",
      commercial: "تجاري",
      administrative: "إداري",
      labor: "عمالي",
      personal: "أحوال",
      realestate: "عقاري",
      intellectual: "ملكية فكرية"
    };
    return map[type] || type;
  };

  const chartData = typeCounts?.map(tc => ({
    name: translateCaseType(tc.type),
    count: tc.count
  })) || [];

  const getNotifIcon = (type: string) => {
    if (type === "success") return <CheckCircle className="w-4 h-4 text-green-500" />;
    if (type === "warning") return <Clock className="w-4 h-4 text-orange-500" />;
    return <AlertCircle className="w-4 h-4 text-blue-500" />;
  };

  const getNotifBg = (type: string) => {
    if (type === "success") return "bg-green-500/10";
    if (type === "warning") return "bg-orange-500/10";
    return "bg-blue-500/10";
  };

  return (
    <div className="space-y-6 pb-8">
      <div>
        <h1 className="text-2xl font-bold mb-1">لوحة التحكم</h1>
        <p className="text-muted-foreground">نظرة عامة على نشاطك القانوني</p>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">إجمالي القضايا</CardTitle>
            <FileText className="w-4 h-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statsLoading ? "..." : stats?.totalCases || 0}</div>
          </CardContent>
        </Card>
        
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">قضايا نشطة</CardTitle>
            <Activity className="w-4 h-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statsLoading ? "..." : stats?.activeCases || 0}</div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">تحليلات مكتملة</CardTitle>
            <CheckCircle className="w-4 h-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statsLoading ? "..." : stats?.completedAnalysis || 0}</div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">قضايا قيد الانتظار</CardTitle>
            <Calendar className="w-4 h-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statsLoading ? "..." : stats?.upcomingSessions || 0}</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart */}
        <Card className="lg:col-span-2 border-border">
          <CardHeader>
            <CardTitle>توزيع القضايا حسب النوع</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] w-full">
              {typesLoading ? (
                <div className="w-full h-full flex items-center justify-center text-muted-foreground">جاري التحميل...</div>
              ) : chartData.length === 0 ? (
                <div className="w-full h-full flex flex-col items-center justify-center text-muted-foreground gap-2">
                  <FileText className="w-10 h-10 opacity-20" />
                  <p className="text-sm">لا توجد قضايا بعد. أضف قضية جديدة للبدء.</p>
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                    <XAxis 
                      dataKey="name" 
                      stroke="#888888" 
                      fontSize={12}
                      tickLine={false}
                      axisLine={false}
                    />
                    <YAxis 
                      stroke="#888888" 
                      fontSize={12}
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={(value) => `${value}`}
                      allowDecimals={false}
                    />
                    <Tooltip 
                      cursor={{fill: 'transparent'}}
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))' }}
                    />
                    <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                      {chartData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill="hsl(var(--primary))" />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Dynamic Notifications */}
        <Card className="border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle>تحديثات هامة</CardTitle>
            <Bell className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {notificationsLoading ? (
              <div className="space-y-3">
                {[1,2,3].map(i => (
                  <div key={i} className="flex gap-3 items-start animate-pulse">
                    <div className="w-8 h-8 rounded-full bg-muted shrink-0" />
                    <div className="flex-1 space-y-1">
                      <div className="h-3 bg-muted rounded w-3/4" />
                      <div className="h-2 bg-muted rounded w-1/4" />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {(notifications ?? []).map((n, i) => (
                  <div key={n.id} className={`flex gap-3 items-start ${i < (notifications?.length ?? 0) - 1 ? "border-b border-border/50 pb-3" : ""}`}>
                    <div className={`w-8 h-8 rounded-full ${getNotifBg(n.type)} flex items-center justify-center shrink-0`}>
                      {getNotifIcon(n.type)}
                    </div>
                    <div>
                      <p className="text-sm font-medium leading-snug">{n.message}</p>
                      <p className="text-xs text-muted-foreground mt-1">{n.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Cases */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle>أحدث القضايا</CardTitle>
        </CardHeader>
        <CardContent>
          {casesLoading ? (
            <div className="text-center py-4 text-muted-foreground">جاري التحميل...</div>
          ) : recentCases && recentCases.length > 0 ? (
            <div className="space-y-4">
              {recentCases.map(c => (
                <div key={c.id} className="flex items-center justify-between p-4 rounded-lg bg-secondary/30 border border-border">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <FileText className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium">{c.title}</h4>
                      <p className="text-sm text-muted-foreground flex items-center gap-2 mt-1">
                        <span>{translateCaseType(c.type)}</span>
                        <span>•</span>
                        <span>{c.court || "لم يحدد محكمة"}</span>
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <Badge variant={c.status === 'active' ? 'default' : 'secondary'} className="font-normal">
                      {c.status === 'active' ? 'نشطة' : c.status === 'pending' ? 'قيد الانتظار' : 'مغلقة'}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {format(new Date(c.date), 'd MMMM yyyy', { locale: ar })}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <FileText className="w-10 h-10 mx-auto mb-2 opacity-20" />
              <p>لا توجد قضايا حديثة</p>
              <p className="text-sm mt-1">ابدأ بإضافة أولى قضاياك</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
