import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "../lib/auth-context";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { User, Scale, ArrowLeft, ArrowRight, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Home() {
  const [_, setLocation] = useLocation();
  const { register, isRegistered } = useAuth();
  
  const [step, setStep] = useState<"role" | "register">("role");
  const [role, setRole] = useState<"citizen" | "lawyer" | null>(null);
  const [name, setName] = useState("");

  if (isRegistered) {
    setLocation("/dashboard");
    return null;
  }

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (role && name) {
      register(role, name);
      setLocation("/dashboard");
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4 relative overflow-hidden text-foreground" dir="rtl">
      
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/10 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[30%] h-[30%] bg-blue-500/10 blur-[100px] rounded-full pointer-events-none" />
      
      <div className="mb-8 text-center z-10">
        <div className="w-16 h-16 rounded-xl bg-primary mx-auto flex items-center justify-center mb-6 shadow-lg shadow-primary/20">
          <span className="text-primary-foreground font-bold font-serif text-4xl">ق</span>
        </div>
        <h1 className="text-3xl font-bold mb-2">القانوني المصري</h1>
        <p className="text-muted-foreground text-lg">منصتك الذكية للخدمات القانونية في مصر</p>
      </div>

      <div className="w-full max-w-2xl z-10 transition-all duration-500 relative">
        {step === "role" && (
          <div className="grid md:grid-cols-2 gap-6 animate-in fade-in slide-in-from-bottom-4">
            <Card 
              className={cn(
                "cursor-pointer transition-all duration-300 hover:border-primary hover:shadow-md hover:shadow-primary/10 group",
                role === "citizen" ? "border-primary ring-1 ring-primary" : "border-border"
              )}
              onClick={() => setRole("citizen")}
            >
              <CardHeader className="text-center pb-4">
                <div className="w-12 h-12 mx-auto bg-secondary rounded-full flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <User className="w-6 h-6 text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
                <CardTitle>مواطن</CardTitle>
                <CardDescription className="text-sm mt-2">
                  أبحث عن استشارة قانونية، مساعدة في قضية، أو توكيل محامي.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card 
              className={cn(
                "cursor-pointer transition-all duration-300 hover:border-primary hover:shadow-md hover:shadow-primary/10 group",
                role === "lawyer" ? "border-primary ring-1 ring-primary" : "border-border"
              )}
              onClick={() => setRole("lawyer")}
            >
              <CardHeader className="text-center pb-4">
                <div className="w-12 h-12 mx-auto bg-secondary rounded-full flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <Scale className="w-6 h-6 text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
                <CardTitle>محامي</CardTitle>
                <CardDescription className="text-sm mt-2">
                  أقدم خدمات قانونية، أبحث عن قضايا، وأدير موكلي.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        )}

        {step === "role" && (
          <div className="mt-8 flex justify-center animate-in fade-in delay-150">
            <Button 
              size="lg" 
              className="w-full md:w-1/2" 
              disabled={!role}
              onClick={() => setStep("register")}
            >
              التالي
              <ArrowLeft className="w-4 h-4 ml-2 mr-2" />
            </Button>
          </div>
        )}

        {step === "register" && (
          <Card className="animate-in fade-in slide-in-from-left-8 border-border shadow-xl">
            <form onSubmit={handleRegister}>
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Button type="button" variant="ghost" size="icon" onClick={() => setStep("role")} className="h-8 w-8">
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                  <CardTitle>إنشاء حساب {role === 'lawyer' ? 'محامي' : 'مواطن'}</CardTitle>
                </div>
                <CardDescription>
                  يرجى إدخال بياناتك للمتابعة والتسجيل في المنصة.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">الاسم بالكامل</Label>
                  <Input 
                    id="name" 
                    placeholder="مثال: أحمد محمد" 
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>
                
                {role === "lawyer" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="barNumber">رقم القيد بنقابة المحامين</Label>
                      <Input id="barNumber" placeholder="مثال: 123456" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="specialty">التخصص الرئيسي</Label>
                      <Select defaultValue="civil">
                        <SelectTrigger>
                          <SelectValue placeholder="اختر التخصص" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="civil">مدني</SelectItem>
                          <SelectItem value="criminal">جنائي</SelectItem>
                          <SelectItem value="commercial">تجاري وشركات</SelectItem>
                          <SelectItem value="labor">عمالي</SelectItem>
                          <SelectItem value="personal">أحوال شخصية</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                )}
                
                {role === "citizen" && (
                  <div className="space-y-2">
                    <Label htmlFor="phone">رقم الهاتف (اختياري)</Label>
                    <Input id="phone" placeholder="01X XXXX XXXX" />
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button type="submit" className="w-full" disabled={!name}>
                  الدخول للمنصة
                  <CheckCircle2 className="w-4 h-4 ml-2 mr-2" />
                </Button>
              </CardFooter>
            </form>
          </Card>
        )}
      </div>
    </div>
  );
}
