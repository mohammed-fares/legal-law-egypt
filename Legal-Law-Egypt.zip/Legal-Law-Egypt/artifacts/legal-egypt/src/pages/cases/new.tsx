import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import { useCreateCase, useGetCaseAnalysis, getGetCaseAnalysisQueryKey } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Building2, Users, FileText, Briefcase, Gavel, 
  Home, BookOpen, Brain, UploadCloud, Camera, 
  CheckCircle2, ArrowRight, ArrowLeft, Lightbulb, 
  AlertTriangle, Crosshair, Scale, Check
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const CASE_TYPES = [
  { id: "civil", label: "مدني", icon: Building2 },
  { id: "criminal", label: "جنائي", icon: Gavel },
  { id: "commercial", label: "تجاري وشركات", icon: Briefcase },
  { id: "personal", label: "أحوال شخصية", icon: Users },
  { id: "administrative", label: "إداري", icon: FileText },
  { id: "labor", label: "عمالي", icon: Users },
  { id: "realestate", label: "عقاري", icon: Home },
  { id: "intellectual", label: "ملكية فكرية", icon: BookOpen },
];

export default function NewCase() {
  const [_, setLocation] = useLocation();
  const [step, setStep] = useState(1);
  const [createdCaseId, setCreatedCaseId] = useState<number | null>(null);

  // Form State
  const [type, setType] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [court, setCourt] = useState("");
  const [courtCaseNumber, setCourtCaseNumber] = useState("");

  const createCaseMutation = useCreateCase();

  // Analysis State
  const [analysisProgress, setAnalysisProgress] = useState(0);
  
  // The query will only run when createdCaseId is set (Step 3)
  const { data: analysisData, isLoading: analysisLoading } = useGetCaseAnalysis(
    createdCaseId ?? 0,
    { query: { 
      enabled: !!createdCaseId && step === 3,
      queryKey: getGetCaseAnalysisQueryKey(createdCaseId ?? 0),
    }}
  );

  useEffect(() => {
    let interval: ReturnType<typeof setInterval> | undefined;
    if (step === 3 && analysisLoading) {
      setAnalysisProgress(0);
      interval = setInterval(() => {
        setAnalysisProgress(prev => {
          if (prev >= 95) return prev;
          return prev + 5;
        });
      }, 200);
    } else if (step === 3 && !analysisLoading && analysisData) {
      setAnalysisProgress(100);
    }
    return () => { if (interval) clearInterval(interval); };
  }, [step, analysisLoading, analysisData]);

  const handleNextStep1 = () => {
    if (!type || !title) {
      toast.error("يرجى اختيار نوع القضية وإدخال العنوان");
      return;
    }
    setStep(2);
  };

  const handleCreateCase = () => {
    createCaseMutation.mutate(
      { data: { type, title, description, court, courtCaseNumber } },
      {
        onSuccess: (data) => {
          setCreatedCaseId(data.id);
          setStep(3); // Move to analysis
        },
        onError: () => {
          toast.error("حدث خطأ أثناء إنشاء القضية");
        }
      }
    );
  };

  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Drag and drop state
  const [isDragging, setIsDragging] = useState(false);
  const onDragOver = (e: React.DragEvent) => { e.preventDefault(); setIsDragging(true); };
  const onDragLeave = (e: React.DragEvent) => { e.preventDefault(); setIsDragging(false); };
  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    toast.success("تم استلام الملفات (محاكاة)");
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      
      {/* Header & Stepper */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-6">قضية جديدة</h1>
        
        <div className="flex items-center justify-between relative bg-[#090e1a] pt-[15px] pb-[15px] pl-[15px] pr-[15px] rounded-[10px] border border-[#232f43]">
          <div className="absolute left-[15px] right-[15px] top-[32px] h-0.5 bg-border -z-10" />
          {[
            { num: 1, label: "البيانات الأساسية" },
            { num: 2, label: "المستندات" },
            { num: 3, label: "تحليل الذكاء الاصطناعي" },
            { num: 4, label: "تم بنجاح" }
          ].map((s) => (
            <div key={s.num} className="flex flex-col items-center gap-2 px-2 bg-[#090e1a]">
              <div className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-colors border-2",
                step === s.num ? "bg-primary border-primary text-primary-foreground" :
                step > s.num ? "bg-primary/20 border-primary text-primary" :
                "bg-card border-border text-muted-foreground"
              )}>
                {step > s.num ? <Check className="w-5 h-5" /> : s.num}
              </div>
              <span className={cn(
                "text-xs font-medium",
                step >= s.num ? "text-foreground" : "text-muted-foreground"
              )}>
                {s.label}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Step 1: Basic Info */}
      {step === 1 && (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
          <Card className="border-border">
            <CardContent className="p-6">
              <h2 className="text-lg font-semibold mb-4">اختر نوع القضية</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {CASE_TYPES.map((t) => {
                  const Icon = t.icon;
                  const isSelected = type === t.id;
                  return (
                    <div 
                      key={t.id}
                      onClick={() => setType(t.id)}
                      className={cn(
                        "flex flex-col items-center justify-center p-4 rounded-xl border-2 cursor-pointer transition-all hover:bg-secondary/50",
                        isSelected ? "border-primary bg-primary/5 text-primary" : "border-border bg-card text-muted-foreground"
                      )}
                    >
                      <Icon className="w-8 h-8 mb-3" />
                      <span className="font-medium text-sm text-center">{t.label}</span>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardContent className="p-6 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">عنوان القضية أو النزاع <span className="text-destructive">*</span></Label>
                <Input 
                  id="title" 
                  value={title} 
                  onChange={(e) => setTitle(e.target.value)} 
                  placeholder="مثال: دعوى صحة ونفاذ عقد بيع" 
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="desc">وصف الوقائع (اختياري، يفيد في دقة التحليل)</Label>
                <Textarea 
                  id="desc" 
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="اسرد وقائع النزاع باختصار..."
                  className="h-24 resize-none"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="court">المحكمة المختصة (إن وجدت)</Label>
                  <Input 
                    id="court" 
                    value={court}
                    onChange={(e) => setCourt(e.target.value)}
                    placeholder="مثال: محكمة شمال القاهرة الابتدائية" 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cnumber">رقم الدعوى (إن وجد)</Label>
                  <Input 
                    id="cnumber" 
                    value={courtCaseNumber}
                    onChange={(e) => setCourtCaseNumber(e.target.value)}
                    placeholder="مثال: 1234 لسنة 2023" 
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end">
            <Button onClick={handleNextStep1} size="lg">
              التالي: المستندات
              <ArrowLeft className="w-4 h-4 ml-2 mr-2" />
            </Button>
          </div>
        </div>
      )}

      {/* Step 2: Documents */}
      {step === 2 && (
        <div className="space-y-6 animate-in fade-in slide-in-from-right-8">
          <Card className="border-border">
            <CardContent className="p-6">
              <div className="text-center mb-6">
                <h2 className="text-lg font-semibold mb-2">إرفاق مستندات القضية</h2>
                <p className="text-sm text-muted-foreground">قم برفع العقود، محاضر الشرطة، أو صحيفة الدعوى ليقوم الذكاء الاصطناعي بتحليلها.</p>
              </div>

              <div 
                className={cn(
                  "border-2 border-dashed rounded-xl p-12 text-center transition-colors",
                  isDragging ? "border-primary bg-primary/5" : "border-border bg-card hover:bg-secondary/20"
                )}
                onDragOver={onDragOver}
                onDragLeave={onDragLeave}
                onDrop={onDrop}
              >
                <UploadCloud className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="font-medium text-lg mb-1">اسحب وأفلت الملفات هنا</h3>
                <p className="text-sm text-muted-foreground mb-6">أو تصفح جهازك لاختيار الملفات (PDF, JPG, PNG)</p>
                
                <input type="file" className="hidden" ref={fileInputRef} multiple />
                
                <div className="flex justify-center gap-4">
                  <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
                    تصفح الملفات
                  </Button>
                  <Button variant="outline">
                    <Camera className="w-4 h-4 ml-2" />
                    التقاط صورة
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-between">
            <Button variant="ghost" onClick={() => setStep(1)}>
              <ArrowRight className="w-4 h-4 ml-2" />
              رجوع
            </Button>
            <Button onClick={handleCreateCase} size="lg" disabled={createCaseMutation.isPending}>
              {createCaseMutation.isPending ? "جاري الإنشاء..." : "بدء التحليل الذكي"}
              <Brain className="w-4 h-4 ml-2 mr-2" />
            </Button>
          </div>
        </div>
      )}

      {/* Step 3: Analysis */}
      {step === 3 && (
        <div className="space-y-6 animate-in fade-in zoom-in-95 duration-500">
          
          {analysisLoading || analysisProgress < 100 ? (
            <Card className="border-primary/50 bg-primary/5 overflow-hidden">
              <CardContent className="p-12 text-center">
                <Brain className="w-16 h-16 text-primary mx-auto mb-6 animate-pulse" />
                <h2 className="text-2xl font-bold mb-3">الذكاء الاصطناعي يقرأ أوراقك...</h2>
                <p className="text-muted-foreground mb-8">نقوم الآن بتحليل الوقائع والمستندات ومطابقتها مع القانون المصري وأحكام النقض.</p>
                
                <div className="max-w-md mx-auto space-y-2">
                  <Progress value={analysisProgress} className="h-2" />
                  <p className="text-xs text-muted-foreground text-left">{analysisProgress}%</p>
                </div>
              </CardContent>
            </Card>
          ) : analysisData && (
            <div className="space-y-6 animate-in slide-in-from-bottom-8">
              
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">نتائج التحليل الذكي</h2>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-medium">نسبة النجاح المتوقعة:</span>
                  <div className="w-16 h-16 rounded-full bg-card border-4 border-primary flex items-center justify-center shadow-[0_0_15px_rgba(212,175,55,0.3)]">
                    <span className="text-xl font-bold text-primary">{analysisData.successRate}%</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Strengths */}
                <Card className="border-green-500/30 bg-green-500/5">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-2 mb-4">
                      <Lightbulb className="w-5 h-5 text-green-500" />
                      <h3 className="font-bold text-lg text-green-500">نقاط القوة</h3>
                    </div>
                    <ul className="space-y-3">
                      {analysisData.strengths.map((s, i) => (
                        <li key={i} className="flex gap-2 text-sm leading-relaxed">
                          <span className="text-green-500 mt-1">•</span>
                          {s}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                {/* Weaknesses */}
                <Card className="border-destructive/30 bg-destructive/5">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-2 mb-4">
                      <AlertTriangle className="w-5 h-5 text-destructive" />
                      <h3 className="font-bold text-lg text-destructive">الثغرات والمخاطر</h3>
                    </div>
                    <ul className="space-y-3">
                      {analysisData.weaknesses.map((s, i) => (
                        <li key={i} className="flex gap-2 text-sm leading-relaxed">
                          <span className="text-destructive mt-1">•</span>
                          {s}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                {/* Missing docs */}
                <Card className="border-orange-500/30 bg-orange-500/5 md:col-span-2">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-2 mb-4">
                      <Crosshair className="w-5 h-5 text-orange-500" />
                      <h3 className="font-bold text-lg text-orange-500">نواقص يجب توفيرها</h3>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {analysisData.gaps.map((g, i) => (
                        <Badge key={i} variant="outline" className="border-orange-500/50 bg-orange-500/10 text-orange-300">
                          {g}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Legal References */}
                <Card className="border-border bg-card md:col-span-2">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-2 mb-6">
                      <Scale className="w-5 h-5 text-primary" />
                      <h3 className="font-bold text-lg">الأسانيد القانونية ذات الصلة</h3>
                    </div>
                    <div className="space-y-4">
                      {analysisData.references.map((ref, i) => (
                        <div key={i} className="pb-4 border-b border-border/50 last:border-0 last:pb-0">
                          <h4 className="font-bold text-primary mb-1">{ref.title}</h4>
                          <p className="text-sm text-muted-foreground font-serif leading-loose">{ref.description}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

              </div>

              <div className="flex justify-end pt-4">
                <Button onClick={() => setStep(4)} size="lg" className="w-full md:w-auto">
                  حفظ القضية
                  <CheckCircle2 className="w-4 h-4 ml-2 mr-2" />
                </Button>
              </div>

            </div>
          )}
        </div>
      )}

      {/* Step 4: Success */}
      {step === 4 && (
        <div className="animate-in zoom-in-95 fade-in duration-500 max-w-md mx-auto">
          <Card className="border-border bg-card text-center overflow-hidden">
            <div className="h-2 bg-green-500 w-full" />
            <CardContent className="p-10">
              <div className="w-20 h-20 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle2 className="w-10 h-10 text-green-500" />
              </div>
              <h2 className="text-2xl font-bold mb-2">تم إنشاء الملف بنجاح</h2>
              <p className="text-muted-foreground mb-8">تم حفظ القضية وإضافة التحليل الذكي إليها بنجاح.</p>
              
              <div className="flex flex-col gap-3">
                <Button onClick={() => setLocation("/cases")} variant="outline" className="w-full">
                  العودة لقائمة القضايا
                </Button>
                <Button onClick={() => setLocation("/dashboard")} className="w-full">
                  الذهاب للوحة التحكم
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

    </div>
  );
}
