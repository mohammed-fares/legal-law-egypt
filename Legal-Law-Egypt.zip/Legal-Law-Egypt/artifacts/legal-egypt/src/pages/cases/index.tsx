import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useGetCases, getGetCasesQueryKey, useDeleteCase, useGetCase } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Search, Plus, MoreVertical, Eye, Trash2, Brain, FileText, Scale, Building2, Gavel, Briefcase, Users, Home, BookOpen } from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { toast } from "sonner";

const TYPE_ICONS: Record<string, React.ElementType> = {
  civil: Building2, criminal: Gavel, commercial: Briefcase,
  administrative: FileText, labor: Users, personal: Users,
  realestate: Home, intellectual: BookOpen,
};

function CaseDetailModal({ caseId, onClose }: { caseId: number; onClose: () => void }) {
  const { data: c, isLoading } = useGetCase(caseId);

  const translateType = (t: string) => {
    const map: Record<string, string> = {
      civil: "مدني", criminal: "جنائي", commercial: "تجاري وشركات",
      administrative: "إداري", labor: "عمالي", personal: "أحوال شخصية",
      realestate: "عقاري", intellectual: "ملكية فكرية"
    };
    return map[t] || t;
  };

  return (
    <DialogContent className="max-w-lg">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Scale className="w-5 h-5 text-primary" />
          تفاصيل القضية
        </DialogTitle>
      </DialogHeader>
      {isLoading ? (
        <div className="py-8 text-center text-muted-foreground">جاري التحميل...</div>
      ) : c ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="font-mono text-xs bg-secondary px-2 py-1 rounded">{c.caseNumber}</span>
            <Badge variant={c.status === 'active' ? 'default' : c.status === 'closed' ? 'outline' : 'secondary'}>
              {c.status === 'active' ? 'نشطة' : c.status === 'pending' ? 'قيد الانتظار' : 'مغلقة'}
            </Badge>
          </div>

          <div>
            <h3 className="font-bold text-lg">{c.title}</h3>
            {c.description && <p className="text-sm text-muted-foreground mt-1 leading-relaxed">{c.description}</p>}
          </div>

          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="bg-secondary/50 rounded-lg p-3">
              <p className="text-xs text-muted-foreground mb-1">نوع القضية</p>
              <p className="font-medium">{translateType(c.type)}</p>
            </div>
            <div className="bg-secondary/50 rounded-lg p-3">
              <p className="text-xs text-muted-foreground mb-1">المحكمة</p>
              <p className="font-medium">{c.court || "لم تُحدد"}</p>
            </div>
            <div className="bg-secondary/50 rounded-lg p-3">
              <p className="text-xs text-muted-foreground mb-1">رقم الدعوى</p>
              <p className="font-medium">{c.courtCaseNumber || "—"}</p>
            </div>
            <div className="bg-secondary/50 rounded-lg p-3">
              <p className="text-xs text-muted-foreground mb-1">تاريخ الإضافة</p>
              <p className="font-medium">{format(new Date(c.date), 'd MMM yyyy', { locale: ar })}</p>
            </div>
          </div>

          <div className="flex items-center gap-2 p-3 rounded-lg border border-border">
            <Brain className={`w-4 h-4 ${c.analysisStatus === 'completed' ? 'text-primary' : 'text-muted-foreground'}`} />
            <div>
              <p className="text-sm font-medium">
                {c.analysisStatus === 'completed' ? 'تم التحليل الذكي' : 
                 c.analysisStatus === 'pending' ? 'في انتظار التحليل' : 'لم يُحلل بعد'}
              </p>
              {c.analysisStatus === 'completed' && (
                <p className="text-xs text-muted-foreground">يمكنك إنشاء قضية جديدة لتحليل ذكي محدّث</p>
              )}
            </div>
          </div>

          <Button variant="outline" onClick={onClose} className="w-full">إغلاق</Button>
        </div>
      ) : (
        <div className="py-8 text-center text-muted-foreground">لم يتم العثور على القضية</div>
      )}
    </DialogContent>
  );
}

export default function CasesList() {
  const [search, setSearch] = useState("");
  const [type, setType] = useState<string>("");
  const [status, setStatus] = useState<string>("");
  const [viewCaseId, setViewCaseId] = useState<number | null>(null);
  const [_, setLocation] = useLocation();
  
  const queryClient = useQueryClient();

  const { data: cases, isLoading } = useGetCases(
    { search, type: type === "all" ? undefined : type, status: status === "all" ? undefined : status },
    { query: { queryKey: getGetCasesQueryKey({ search, type: type === "all" ? undefined : type, status: status === "all" ? undefined : status }) } }
  );

  const deleteCaseMutation = useDeleteCase();

  const handleDelete = (id: number) => {
    if (confirm("هل أنت متأكد من حذف هذه القضية؟")) {
      deleteCaseMutation.mutate({ id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetCasesQueryKey() });
          toast.success("تم حذف القضية بنجاح");
        },
        onError: () => toast.error("حدث خطأ أثناء الحذف")
      });
    }
  };

  const translateType = (t: string) => {
    const map: Record<string, string> = {
      civil: "مدني", criminal: "جنائي", commercial: "تجاري", 
      administrative: "إداري", labor: "عمالي", personal: "أحوال شخصية", 
      realestate: "عقاري", intellectual: "ملكية فكرية"
    };
    return map[t] || t;
  };

  return (
    <div className="space-y-6 pb-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold mb-1">ملفات القضايا</h1>
          <p className="text-muted-foreground">إدارة وتتبع جميع قضاياك</p>
        </div>
        <Link href="/cases/new">
          <Button className="shrink-0 gap-2">
            <Plus className="w-4 h-4" />
            إضافة قضية
          </Button>
        </Link>
      </div>

      <Card className="border-border">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="ابحث برقم القضية، العنوان، أو المحكمة..." 
                className="pl-3 pr-10"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <div className="flex gap-4 w-full md:w-auto">
              <Select value={type} onValueChange={setType}>
                <SelectTrigger className="w-full md:w-[160px]">
                  <SelectValue placeholder="نوع القضية" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">الكل</SelectItem>
                  <SelectItem value="civil">مدني</SelectItem>
                  <SelectItem value="criminal">جنائي</SelectItem>
                  <SelectItem value="commercial">تجاري</SelectItem>
                  <SelectItem value="labor">عمالي</SelectItem>
                  <SelectItem value="personal">أحوال شخصية</SelectItem>
                  <SelectItem value="realestate">عقاري</SelectItem>
                  <SelectItem value="administrative">إداري</SelectItem>
                </SelectContent>
              </Select>
              <Select value={status} onValueChange={setStatus}>
                <SelectTrigger className="w-full md:w-[140px]">
                  <SelectValue placeholder="الحالة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">الكل</SelectItem>
                  <SelectItem value="active">نشطة</SelectItem>
                  <SelectItem value="pending">قيد الانتظار</SelectItem>
                  <SelectItem value="closed">مغلقة</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {isLoading ? (
        <Card className="border-border">
          <CardContent className="py-16 text-center text-muted-foreground">جاري التحميل...</CardContent>
        </Card>
      ) : cases && cases.length > 0 ? (
        <Card className="border-border overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-secondary/50">
                <TableRow className="border-border hover:bg-transparent">
                  <TableHead className="text-right">رقم القضية</TableHead>
                  <TableHead className="text-right">العنوان</TableHead>
                  <TableHead className="text-right">النوع</TableHead>
                  <TableHead className="text-right">المحكمة</TableHead>
                  <TableHead className="text-right">التاريخ</TableHead>
                  <TableHead className="text-right">الحالة</TableHead>
                  <TableHead className="text-right">التحليل الذكي</TableHead>
                  <TableHead className="w-[80px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {cases.map((c) => {
                  const TypeIcon = TYPE_ICONS[c.type] || FileText;
                  return (
                    <TableRow key={c.id} className="border-border hover:bg-secondary/20 cursor-pointer" onClick={() => setViewCaseId(c.id)}>
                      <TableCell className="font-mono text-xs">{c.caseNumber}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <TypeIcon className="w-4 h-4 text-primary shrink-0" />
                          <span className="font-medium max-w-[180px] truncate" title={c.title}>{c.title}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="font-normal bg-background text-xs">
                          {translateType(c.type)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm max-w-[130px] truncate" title={c.court || ""}>
                        {c.court || "—"}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {format(new Date(c.date), 'dd/MM/yyyy')}
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant={c.status === 'active' ? 'default' : c.status === 'closed' ? 'outline' : 'secondary'}
                          className="font-normal text-xs"
                        >
                          {c.status === 'active' ? 'نشطة' : c.status === 'pending' ? 'انتظار' : 'مغلقة'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {c.analysisStatus === 'completed' ? (
                          <div className="flex items-center gap-1.5 text-primary text-sm font-medium">
                            <Brain className="w-4 h-4" />
                            <span>محللة</span>
                          </div>
                        ) : (
                          <span className="text-xs text-muted-foreground">لم تحلل</span>
                        )}
                      </TableCell>
                      <TableCell onClick={(e) => e.stopPropagation()}>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-[160px]">
                            <DropdownMenuItem className="cursor-pointer" onClick={() => setViewCaseId(c.id)}>
                              <Eye className="w-4 h-4 ml-2" />
                              عرض التفاصيل
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              className="cursor-pointer text-destructive focus:bg-destructive/10 focus:text-destructive"
                              onClick={() => handleDelete(c.id)}
                            >
                              <Trash2 className="w-4 h-4 ml-2" />
                              حذف
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </Card>
      ) : (
        <Card className="border-border">
          <CardContent className="py-16 text-center text-muted-foreground">
            <Scale className="w-12 h-12 mx-auto mb-3 opacity-20" />
            <p className="font-medium">لا توجد قضايا مطابقة للبحث</p>
            <p className="text-sm mt-1">جرب تغيير معايير البحث أو أضف قضية جديدة</p>
            <Link href="/cases/new">
              <Button className="mt-4" size="sm">
                <Plus className="w-4 h-4 ml-1" />
                إضافة قضية
              </Button>
            </Link>
          </CardContent>
        </Card>
      )}

      {/* Case Detail Modal */}
      <Dialog open={!!viewCaseId} onOpenChange={open => !open && setViewCaseId(null)}>
        {viewCaseId && <CaseDetailModal caseId={viewCaseId} onClose={() => setViewCaseId(null)} />}
      </Dialog>
    </div>
  );
}
