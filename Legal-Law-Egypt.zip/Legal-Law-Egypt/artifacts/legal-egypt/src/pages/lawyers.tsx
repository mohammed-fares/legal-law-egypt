import { useState } from "react";
import { useGetLawyers, getGetLawyersQueryKey } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Search, Star, MapPin, Briefcase, MessageSquare, Phone, Award, Clock, CheckCircle, X, Scale, Calendar, Globe } from "lucide-react";

const SPECIALTIES = [
  { value: "all", label: "كل التخصصات" },
  { value: "civil", label: "مدني" },
  { value: "criminal", label: "جنائي" },
  { value: "commercial", label: "تجاري وشركات" },
  { value: "labor", label: "عمالي" },
  { value: "personal", label: "أحوال شخصية" },
  { value: "realestate", label: "عقاري" },
  { value: "administrative", label: "إداري" },
  { value: "intellectual", label: "ملكية فكرية" },
];

const CITIES = [
  { value: "all", label: "كل المحافظات" },
  { value: "cairo", label: "القاهرة" },
  { value: "giza", label: "الجيزة" },
  { value: "alexandria", label: "الإسكندرية" },
];

interface Lawyer {
  id: number;
  name: string;
  specialty: string;
  branch: string;
  experience: string;
  rating: number;
  casesCount: number;
  online: boolean;
  initials?: string;
}

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1,2,3,4,5].map(s => (
        <Star key={s} className={`w-3 h-3 ${s <= Math.round(rating) ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground/30"}`} />
      ))}
      <span className="text-xs font-bold text-yellow-500 mr-1">{rating.toFixed(1)}</span>
    </div>
  );
}

function ConsultationModal({ lawyer, onClose }: { lawyer: Lawyer; onClose: () => void }) {
  const [message, setMessage] = useState("");
  const [sent, setSent] = useState(false);
  const [sending, setSending] = useState(false);
  const [type, setType] = useState<"consultation" | "call">("consultation");
  const [preferredTime, setPreferredTime] = useState("");
  const [subject, setSubject] = useState("");

  const handleSend = async () => {
    if (type === "consultation" && !message.trim()) return;
    setSending(true);
    try {
      await fetch("/api/consultations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          lawyerId: lawyer.id,
          lawyerName: lawyer.name,
          type,
          message: message || null,
          preferredTime: preferredTime || null,
          subject: subject || null,
        }),
      });
      setSent(true);
    } catch {
      setSent(true);
    } finally {
      setSending(false);
    }
  };

  return (
    <DialogContent className="max-w-lg">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-orange-400 flex items-center justify-center text-white font-bold">
            {lawyer.initials || lawyer.name.charAt(0)}
          </div>
          <div>
            <p className="font-bold">{lawyer.name}</p>
            <p className="text-sm text-primary font-normal">{lawyer.specialty}</p>
          </div>
        </DialogTitle>
      </DialogHeader>

      {sent ? (
        <div className="flex flex-col items-center justify-center py-8 gap-4">
          <div className="w-16 h-16 rounded-full bg-green-500/10 flex items-center justify-center">
            <CheckCircle className="w-8 h-8 text-green-500" />
          </div>
          <div className="text-center">
            <p className="font-bold text-lg">تم إرسال طلبك بنجاح</p>
            <p className="text-sm text-muted-foreground mt-1">سيتواصل معك المحامي {lawyer.name} في أقرب وقت</p>
          </div>
          <Button onClick={onClose} variant="outline" className="mt-2">إغلاق</Button>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex gap-2">
            <Button
              variant={type === "consultation" ? "default" : "outline"}
              size="sm"
              onClick={() => setType("consultation")}
              className="flex-1 gap-1.5"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              استشارة مكتوبة
            </Button>
            <Button
              variant={type === "call" ? "default" : "outline"}
              size="sm"
              onClick={() => setType("call")}
              className="flex-1 gap-1.5"
            >
              <Phone className="w-3.5 h-3.5" />
              حجز مكالمة
            </Button>
          </div>

          {type === "consultation" ? (
            <>
              <div>
                <label className="text-sm font-medium mb-1.5 block">اشرح قضيتك باختصار</label>
                <Textarea
                  placeholder="اكتب ملخصاً لمشكلتك القانونية وما تحتاج إليه من مساعدة..."
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                  className="min-h-[120px] resize-none"
                />
              </div>
              <div className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
                <Clock className="w-4 h-4 text-primary shrink-0" />
                <p className="text-xs text-muted-foreground">متوسط وقت الرد: {lawyer.online ? "أقل من ساعة" : "خلال يوم عمل"}</p>
              </div>
            </>
          ) : (
            <>
              <div>
                <label className="text-sm font-medium mb-1.5 block">الوقت المفضل للمكالمة</label>
                <Select value={preferredTime} onValueChange={setPreferredTime}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر الوقت المناسب" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="morning">صباحاً (9 ص - 12 م)</SelectItem>
                    <SelectItem value="noon">ظهراً (12 م - 3 م)</SelectItem>
                    <SelectItem value="afternoon">عصراً (3 م - 6 م)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium mb-1.5 block">موضوع الاستشارة</label>
                <Input
                  placeholder="مثال: نزاع عقاري، قضية طلاق..."
                  value={subject}
                  onChange={e => setSubject(e.target.value)}
                />
              </div>
              <div className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
                <Calendar className="w-4 h-4 text-primary shrink-0" />
                <p className="text-xs text-muted-foreground">سيتم تأكيد الموعد خلال ساعتين من الطلب</p>
              </div>
            </>
          )}

          <div className="flex gap-2 pt-2">
            <Button
              onClick={handleSend}
              disabled={sending || (type === "consultation" && !message.trim())}
              className="flex-1"
            >
              {sending ? "جاري الإرسال..." : type === "consultation" ? "إرسال الطلب" : "حجز المكالمة"}
            </Button>
            <Button variant="outline" onClick={onClose}>إلغاء</Button>
          </div>
        </div>
      )}
    </DialogContent>
  );
}

function LawyerCard({ lawyer, onConsult }: { lawyer: Lawyer; onConsult: (l: Lawyer) => void }) {
  const [expanded, setExpanded] = useState(false);

  const achievements = [
    "عضو نقابة المحامين المصريين",
    "خبرة في المحاكم الابتدائية والاستئناف",
    lawyer.casesCount > 100 ? "أكثر من 100 قضية ناجحة" : `${lawyer.casesCount} قضية مكتملة`,
  ];

  return (
    <Card className="border-border bg-card hover:border-primary/40 transition-all group overflow-hidden flex flex-col">
      {/* Header strip */}
      <div className="h-14 bg-gradient-to-l from-primary/20 to-primary/5 relative">
        <div className="absolute -bottom-6 right-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-orange-400 p-0.5 shadow-md">
            <div className="w-full h-full bg-card rounded-[10px] flex items-center justify-center text-base font-bold">
              {lawyer.initials || lawyer.name.charAt(0)}
            </div>
          </div>
          {lawyer.online && (
            <div className="absolute top-0 -right-1 w-3.5 h-3.5 bg-green-500 border-2 border-card rounded-full" />
          )}
        </div>
        <div className="absolute top-3 left-3">
          <Badge variant={lawyer.online ? "default" : "secondary"} className="text-[10px] px-1.5">
            {lawyer.online ? "متاح الآن" : "غير متاح"}
          </Badge>
        </div>
      </div>

      <CardContent className="pt-8 pb-4 px-4 flex flex-col flex-1">
        <div className="flex justify-between items-start mb-1">
          <h3 className="font-bold text-base">{lawyer.name}</h3>
          <StarRating rating={lawyer.rating} />
        </div>

        <p className="text-sm text-primary font-medium mb-3">{lawyer.specialty}</p>

        <div className="space-y-1.5 mb-3 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <MapPin className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">{lawyer.branch}</span>
          </div>
          <div className="flex items-center gap-2">
            <Briefcase className="w-3.5 h-3.5 shrink-0" />
            <span>{lawyer.experience} خبرة</span>
          </div>
          <div className="flex items-center gap-2">
            <Scale className="w-3.5 h-3.5 shrink-0" />
            <span>{lawyer.casesCount} قضية مكتملة</span>
          </div>
        </div>

        {expanded && (
          <div className="mb-3 space-y-1.5">
            <p className="text-xs font-medium text-foreground mb-2">الإنجازات والمميزات:</p>
            {achievements.map((a, i) => (
              <div key={i} className="flex items-center gap-2 text-xs text-muted-foreground">
                <Award className="w-3 h-3 text-primary shrink-0" />
                <span>{a}</span>
              </div>
            ))}
            <div className="flex items-center gap-2 text-xs text-muted-foreground mt-2">
              <Globe className="w-3 h-3 text-primary shrink-0" />
              <span>يعمل أمام محاكم: القاهرة، الجيزة</span>
            </div>
          </div>
        )}

        <button
          onClick={() => setExpanded(!expanded)}
          className="text-xs text-primary hover:underline text-right mb-3"
        >
          {expanded ? "عرض أقل" : "عرض المزيد"}
        </button>

        <div className="flex gap-2 mt-auto">
          <Button onClick={() => onConsult(lawyer)} className="flex-1 text-xs" size="sm">
            <MessageSquare className="w-3 h-3 ml-1" />
            استشارة
          </Button>
          <Button variant="outline" onClick={() => onConsult(lawyer)} className="flex-1 text-xs" size="sm">
            <Phone className="w-3 h-3 ml-1" />
            اتصال
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export default function LawyersDirectory() {
  const [search, setSearch] = useState("");
  const [specialty, setSpecialty] = useState("all");
  const [city, setCity] = useState("all");
  const [onlineOnly, setOnlineOnly] = useState(false);
  const [selectedLawyer, setSelectedLawyer] = useState<Lawyer | null>(null);
  const [sortBy, setSortBy] = useState<"rating" | "cases" | "name">("rating");

  const { data: lawyers, isLoading } = useGetLawyers(
    { search, specialty: specialty === "all" ? undefined : specialty },
    { query: { queryKey: getGetLawyersQueryKey({ search, specialty: specialty === "all" ? undefined : specialty }) } }
  );

  const filtered = (lawyers ?? [])
    .filter(l => !onlineOnly || l.online)
    .sort((a, b) => {
      if (sortBy === "rating") return b.rating - a.rating;
      if (sortBy === "cases") return b.casesCount - a.casesCount;
      return a.name.localeCompare(b.name, "ar");
    });

  const activeFilters = [
    specialty !== "all" && SPECIALTIES.find(s => s.value === specialty)?.label,
    city !== "all" && CITIES.find(c => c.value === city)?.label,
    onlineOnly && "متاحون الآن",
  ].filter(Boolean) as string[];

  return (
    <div className="space-y-6 pb-8">
      <div>
        <h1 className="text-2xl font-bold mb-1">دليل المحامين</h1>
        <p className="text-muted-foreground">ابحث عن أفضل المحامين المتخصصين في مصر وتواصل معهم مباشرة</p>
      </div>

      {/* Filters */}
      <Card className="border-border bg-card">
        <CardContent className="p-4 space-y-3">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="ابحث بالاسم أو التخصص..."
                className="pl-3 pr-10"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <Select value={specialty} onValueChange={setSpecialty}>
              <SelectTrigger className="w-full md:w-[200px]">
                <SelectValue placeholder="التخصص" />
              </SelectTrigger>
              <SelectContent>
                {SPECIALTIES.map(s => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={city} onValueChange={setCity}>
              <SelectTrigger className="w-full md:w-[160px]">
                <SelectValue placeholder="المحافظة" />
              </SelectTrigger>
              <SelectContent>
                {CITIES.map(c => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setOnlineOnly(!onlineOnly)}
              className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full border transition-colors ${onlineOnly ? "bg-green-500/10 border-green-500/30 text-green-600" : "border-border hover:bg-muted"}`}
            >
              <div className={`w-2 h-2 rounded-full ${onlineOnly ? "bg-green-500" : "bg-muted-foreground/40"}`} />
              متاح الآن فقط
            </button>

            <div className="flex items-center gap-1 mr-auto">
              <span className="text-xs text-muted-foreground">ترتيب حسب:</span>
              {[{ v: "rating", l: "التقييم" }, { v: "cases", l: "القضايا" }, { v: "name", l: "الاسم" }].map(o => (
                <button
                  key={o.v}
                  onClick={() => setSortBy(o.v as typeof sortBy)}
                  className={`text-xs px-2.5 py-1 rounded-md transition-colors ${sortBy === o.v ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`}
                >
                  {o.l}
                </button>
              ))}
            </div>
          </div>

          {activeFilters.length > 0 && (
            <div className="flex flex-wrap gap-2 pt-1">
              {activeFilters.map((f, i) => (
                <Badge key={i} variant="secondary" className="gap-1 text-xs">
                  {f}
                  <button onClick={() => {
                    if (f === "متاحون الآن") setOnlineOnly(false);
                    else if (SPECIALTIES.find(s => s.label === f)) setSpecialty("all");
                    else setCity("all");
                  }}>
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
              <button onClick={() => { setSpecialty("all"); setCity("all"); setOnlineOnly(false); setSearch(""); }}
                className="text-xs text-muted-foreground hover:text-foreground">
                مسح الكل
              </button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Results count */}
      {!isLoading && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            {filtered.length === 0 ? "لا توجد نتائج" : `${filtered.length} محامٍ`}
          </p>
        </div>
      )}

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {isLoading ? (
          Array.from({ length: 8 }).map((_, i) => (
            <Card key={i} className="border-border bg-card animate-pulse h-72" />
          ))
        ) : filtered.length > 0 ? (
          filtered.map((lawyer) => (
            <LawyerCard key={lawyer.id} lawyer={lawyer} onConsult={setSelectedLawyer} />
          ))
        ) : (
          <div className="col-span-full text-center py-16 text-muted-foreground">
            <Scale className="w-12 h-12 mx-auto mb-3 opacity-20" />
            <p className="font-medium">لا يوجد محامون يطابقون بحثك</p>
            <p className="text-sm mt-1">جرب تغيير معايير البحث</p>
          </div>
        )}
      </div>

      {/* Consultation Modal */}
      <Dialog open={!!selectedLawyer} onOpenChange={open => !open && setSelectedLawyer(null)}>
        {selectedLawyer && <ConsultationModal lawyer={selectedLawyer} onClose={() => setSelectedLawyer(null)} />}
      </Dialog>
    </div>
  );
}
