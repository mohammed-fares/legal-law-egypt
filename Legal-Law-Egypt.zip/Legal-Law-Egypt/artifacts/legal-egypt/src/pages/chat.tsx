import { useState, useRef, useEffect, useCallback } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Send, Bot, User, Plus, Trash2, Scale, MessageSquare, Loader2, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

interface Conversation {
  id: number;
  title: string;
  createdAt: string;
}

interface AiMessage {
  id?: number;
  conversationId?: number;
  role: "user" | "assistant";
  content: string;
  createdAt?: string;
  streaming?: boolean;
}

const BASE = "/api";

async function apiGet(path: string) {
  const res = await fetch(`${BASE}${path}`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function apiPost(path: string, body: unknown) {
  const res = await fetch(`${BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function apiDelete(path: string) {
  await fetch(`${BASE}${path}`, { method: "DELETE" });
}

export default function Chat() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConvId, setActiveConvId] = useState<number | null>(null);
  const [messages, setMessages] = useState<AiMessage[]>([]);
  const [input, setInput] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [loadingConvs, setLoadingConvs] = useState(true);
  const [loadingMsgs, setLoadingMsgs] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  };

  useEffect(() => { scrollToBottom(); }, [messages]);

  // Load conversations
  const loadConversations = useCallback(async () => {
    try {
      const data = await apiGet("/anthropic/conversations");
      setConversations(data);
      if (data.length > 0 && !activeConvId) {
        setActiveConvId(data[0].id);
      }
    } catch {
      // ignore
    } finally {
      setLoadingConvs(false);
    }
  }, [activeConvId]);

  useEffect(() => { loadConversations(); }, []);

  // Load messages for active conversation
  useEffect(() => {
    if (!activeConvId) { setMessages([]); return; }
    setLoadingMsgs(true);
    apiGet(`/anthropic/conversations/${activeConvId}/messages`)
      .then(setMessages)
      .catch(() => setMessages([]))
      .finally(() => setLoadingMsgs(false));
  }, [activeConvId]);

  const createConversation = async () => {
    const title = `محادثة ${new Date().toLocaleDateString("ar-EG")} - ${new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" })}`;
    try {
      const conv = await apiPost("/anthropic/conversations", { title });
      setConversations(prev => [conv, ...prev]);
      setActiveConvId(conv.id);
      setMessages([]);
    } catch {
      // ignore
    }
  };

  const deleteConversation = async (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    await apiDelete(`/anthropic/conversations/${id}`);
    setConversations(prev => prev.filter(c => c.id !== id));
    if (activeConvId === id) {
      const remaining = conversations.filter(c => c.id !== id);
      setActiveConvId(remaining.length > 0 ? remaining[0].id : null);
    }
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isStreaming) return;

    let convId = activeConvId;
    if (!convId) {
      const title = input.slice(0, 50) + (input.length > 50 ? "..." : "");
      try {
        const conv = await apiPost("/anthropic/conversations", { title });
        setConversations(prev => [conv, ...prev]);
        setActiveConvId(conv.id);
        convId = conv.id;
      } catch { return; }
    }

    const userMsg: AiMessage = { role: "user", content: input, createdAt: new Date().toISOString() };
    setMessages(prev => [...prev, userMsg]);
    const sentContent = input;
    setInput("");
    setIsStreaming(true);

    // Add streaming placeholder
    const streamingMsg: AiMessage = { role: "assistant", content: "", createdAt: new Date().toISOString(), streaming: true };
    setMessages(prev => [...prev, streamingMsg]);

    try {
      const res = await fetch(`${BASE}/anthropic/conversations/${convId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: sentContent }),
      });

      if (!res.body) throw new Error("No stream");
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";

        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          try {
            const data = JSON.parse(line.slice(6));
            if (data.content) {
              setMessages(prev => {
                const updated = [...prev];
                const last = updated[updated.length - 1];
                if (last.streaming) {
                  updated[updated.length - 1] = { ...last, content: last.content + data.content };
                }
                return updated;
              });
              scrollToBottom();
            }
            if (data.done) {
              setMessages(prev => {
                const updated = [...prev];
                const last = updated[updated.length - 1];
                if (last.streaming) {
                  updated[updated.length - 1] = { ...last, streaming: false };
                }
                return updated;
              });
            }
          } catch { /* skip */ }
        }
      }
    } catch {
      setMessages(prev => {
        const updated = [...prev];
        const last = updated[updated.length - 1];
        if (last.streaming) {
          updated[updated.length - 1] = { ...last, content: "حدث خطأ في الاتصال. يرجى المحاولة مرة أخرى.", streaming: false };
        }
        return updated;
      });
    } finally {
      setIsStreaming(false);
      inputRef.current?.focus();
    }
  };

  const activeConv = conversations.find(c => c.id === activeConvId);

  const SUGGESTIONS = [
    "ما هي إجراءات رفع دعوى مدنية في مصر؟",
    "ما هي حقوق العامل في قانون العمل المصري؟",
    "كيف أرفع شكوى ضد مالك العقار؟",
    "ما هي مدد التقادم في القانون المصري؟",
    "ما هي إجراءات الطلاق في القانون المصري؟",
  ];

  return (
    <div className="h-[calc(100vh-8rem)] flex gap-4 overflow-hidden">

      {/* Sidebar */}
      <Card className="w-72 border-border bg-card flex flex-col shrink-0 overflow-hidden hidden md:flex">
        <div className="p-3 border-b border-border">
          <Button onClick={createConversation} className="w-full gap-2" size="sm">
            <Plus className="w-4 h-4" />
            محادثة جديدة
          </Button>
        </div>
        <ScrollArea className="flex-1">
          <div className="p-2 space-y-1">
            {loadingConvs ? (
              <div className="flex justify-center py-8"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>
            ) : conversations.length === 0 ? (
              <div className="text-center py-8 text-sm text-muted-foreground">
                <Scale className="w-8 h-8 mx-auto mb-2 opacity-30" />
                <p>لا توجد محادثات</p>
                <p className="text-xs mt-1">ابدأ محادثة جديدة</p>
              </div>
            ) : (
              conversations.map(conv => (
                <div
                  key={conv.id}
                  onClick={() => setActiveConvId(conv.id)}
                  className={cn(
                    "p-3 rounded-lg cursor-pointer transition-colors flex items-center gap-2 group",
                    activeConvId === conv.id ? "bg-primary/10 border border-primary/20" : "hover:bg-secondary/50"
                  )}
                >
                  <MessageSquare className="w-4 h-4 text-muted-foreground shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{conv.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {format(new Date(conv.createdAt), "d MMM", { locale: ar })}
                    </p>
                  </div>
                  <button
                    onClick={(e) => deleteConversation(conv.id, e)}
                    className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive transition-all shrink-0"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>
        </ScrollArea>

        {/* Legal disclaimer */}
        <div className="p-3 border-t border-border bg-muted/30">
          <div className="flex items-start gap-2">
            <Scale className="w-3.5 h-3.5 text-primary shrink-0 mt-0.5" />
            <p className="text-[10px] text-muted-foreground leading-relaxed">
              المساعد متخصص في القانون المصري فقط. للقضايا المعقدة استشر محامياً مرخصاً.
            </p>
          </div>
        </div>
      </Card>

      {/* Main Chat Area */}
      <Card className="flex-1 border-border bg-card flex flex-col overflow-hidden">
        {/* Header */}
        <div className="h-14 border-b border-border flex items-center px-4 gap-3 shrink-0">
          <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center shrink-0">
            <Scale className="w-5 h-5 text-primary-foreground" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-sm">المساعد القانوني الذكي</h3>
              <Badge variant="secondary" className="text-[10px] px-1.5 py-0">متخصص</Badge>
            </div>
            <p className="text-xs text-muted-foreground truncate">
              {activeConv ? activeConv.title : "القانون المصري فقط — مدعوم بالذكاء الاصطناعي"}
            </p>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <div className="w-2 h-2 bg-green-500 rounded-full" />
            <span className="text-xs text-muted-foreground">متصل</span>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4" ref={scrollRef}>
          {loadingMsgs ? (
            <div className="flex h-full items-center justify-center text-muted-foreground">
              <Loader2 className="w-5 h-5 animate-spin ml-2" />
              جاري تحميل المحادثة...
            </div>
          ) : messages.length === 0 ? (
            <div className="flex flex-col h-full items-center justify-center space-y-6 py-8">
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
                <Scale className="w-8 h-8 text-primary" />
              </div>
              <div className="text-center">
                <h3 className="font-bold text-lg mb-1">المساعد القانوني الذكي</h3>
                <p className="text-sm text-muted-foreground max-w-sm">
                  متخصص حصراً في القانون المصري. اسألني عن حقوقك، إجراءات التقاضي، القوانين المصرية وأكثر.
                </p>
              </div>
              <div className="w-full max-w-md space-y-2">
                <p className="text-xs text-muted-foreground text-center mb-3">أسئلة مقترحة:</p>
                {SUGGESTIONS.map((s, i) => (
                  <button
                    key={i}
                    onClick={() => { setInput(s); inputRef.current?.focus(); }}
                    className="w-full text-right text-sm p-3 rounded-lg border border-border hover:bg-primary/5 hover:border-primary/30 transition-colors flex items-center gap-2 group"
                  >
                    <ChevronRight className="w-3.5 h-3.5 text-primary shrink-0 group-hover:translate-x-[-2px] transition-transform" />
                    <span>{s}</span>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((msg, i) => {
              const isUser = msg.role === "user";
              return (
                <div key={i} className={cn("flex gap-3", isUser ? "flex-row" : "flex-row-reverse")}>
                  <div className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center shrink-0 mt-1",
                    isUser ? "bg-secondary text-foreground" : "bg-primary text-primary-foreground"
                  )}>
                    {isUser ? <User className="w-4 h-4" /> : <Scale className="w-4 h-4" />}
                  </div>
                  <div className={cn("max-w-[78%] flex flex-col", isUser ? "items-start" : "items-end")}>
                    <div className={cn(
                      "p-3 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap",
                      isUser
                        ? "bg-secondary text-foreground rounded-br-sm"
                        : "bg-primary text-primary-foreground rounded-bl-sm"
                    )}>
                      {msg.content}
                      {msg.streaming && (
                        <span className="inline-block w-1.5 h-4 bg-primary-foreground/60 animate-pulse mr-0.5 rounded-sm" />
                      )}
                    </div>
                    {msg.createdAt && !msg.streaming && (
                      <span className="text-[10px] text-muted-foreground mt-1 mx-1">
                        {format(new Date(msg.createdAt), "h:mm a", { locale: ar })}
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Input */}
        <div className="p-4 border-t border-border bg-card shrink-0">
          {!activeConvId && conversations.length > 0 && (
            <p className="text-xs text-muted-foreground text-center mb-2">اختر محادثة أو ابدأ واحدة جديدة</p>
          )}
          <form onSubmit={sendMessage} className="flex gap-2">
            <Input
              ref={inputRef}
              placeholder="اسأل عن القانون المصري..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="flex-1 bg-background"
              disabled={isStreaming}
            />
            <Button
              type="submit"
              disabled={!input.trim() || isStreaming}
              className="shrink-0"
            >
              {isStreaming
                ? <Loader2 className="w-4 h-4 animate-spin" />
                : <Send className="w-4 h-4 rotate-180" />
              }
            </Button>
          </form>
          <p className="text-[10px] text-muted-foreground text-center mt-2">
            المساعد متخصص في القانون المصري فقط • الردود لأغراض إرشادية ولا تُغني عن المحامي
          </p>
        </div>
      </Card>
    </div>
  );
}
