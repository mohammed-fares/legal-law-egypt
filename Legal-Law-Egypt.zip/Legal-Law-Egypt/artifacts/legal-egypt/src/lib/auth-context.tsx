import { createContext, useContext, useState, ReactNode, useEffect } from "react";

type Role = "citizen" | "lawyer" | null;

interface AuthState {
  role: Role;
  name: string;
  isRegistered: boolean;
}

interface AuthContextType extends AuthState {
  register: (role: Role, name: string) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState>(() => {
    const saved = localStorage.getItem("legal_auth");
    if (saved) return JSON.parse(saved);
    return { role: null, name: "", isRegistered: false };
  });

  useEffect(() => {
    localStorage.setItem("legal_auth", JSON.stringify(state));
  }, [state]);

  const register = (role: Role, name: string) => {
    setState({ role, name, isRegistered: true });
  };

  const logout = () => {
    setState({ role: null, name: "", isRegistered: false });
  };

  return (
    <AuthContext.Provider value={{ ...state, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
