import { Router } from "express";
import { db } from "@workspace/db";
import { messages } from "@workspace/db";
import { eq } from "drizzle-orm";
import { GetMessagesQueryParams, CreateMessageBody } from "@workspace/api-zod";

const router = Router();

router.get("/messages", async (req, res) => {
  try {
    const parsed = GetMessagesQueryParams.safeParse(req.query);
    if (!parsed.success || !parsed.data.chatId) {
      return res.status(400).json({ error: "chatId is required" });
    }

    const rows = await db.select().from(messages)
      .where(eq(messages.conversationId, parseInt(parsed.data.chatId, 10)))
      .orderBy(messages.createdAt);

    res.json(rows.map((m) => ({
      id: m.id,
      chatId: m.conversationId,
      role: m.role,
      content: m.content,
      createdAt: m.createdAt.toISOString(),
    })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/messages", async (req, res) => {
  try {
    const body = CreateMessageBody.parse(req.body);

    const [msg] = await db.insert(messages).values({
      conversationId: parseInt(body.chatId, 10),
      role: body.senderType ?? "user",
      content: body.content,
    }).returning();

    res.status(201).json({
      id: msg.id,
      chatId: msg.conversationId,
      role: msg.role,
      content: msg.content,
      createdAt: msg.createdAt.toISOString(),
    });
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: "Bad request" });
  }
});

export default router;
