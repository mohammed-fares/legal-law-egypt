import { Router } from "express";
import Anthropic from "@anthropic-ai/sdk";
import { db } from "@workspace/db";
import { sql } from "drizzle-orm";

const router = Router();

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

const SYSTEM_PROMPT = `أنت مساعد قانوني متخصص حصراً في القانون المصري. اسمك "المستشار القانوني المصري".

قواعد صارمة يجب الالتزام بها:
1. أجب فقط على الأسئلة المتعلقة بالقانون المصري والإجراءات القانونية في مصر
2. لا تتطرق أبداً لأي موضوع خارج نطاق القانون المصري (سياسة، دين، ترفيه، طب، إلخ)
3. إذا سُئلت عن موضوع خارج القانون المصري، أعتذر بلطف وأوضح تخصصك
4. استند دائماً إلى القوانين المصرية المحددة وأرقامها وسنواتها ومواد قانونية محددة
5. أجب باللغة العربية الفصحى دائماً
6. قدم إجابات عملية ومنظمة تساعد المستخدم فعلياً
7. في نهاية كل إجابة، انصح بالتواصل مع محامٍ متخصص للحالات المعقدة

التخصصات التي تشملها:
- القانون المدني المصري (القانون 131 لسنة 1948)
- قانون العقوبات (القانون 58 لسنة 1937)
- قانون المرافعات المدنية والتجارية (القانون 13 لسنة 1968)
- قانون الإجراءات الجنائية (القانون 150 لسنة 1950)
- قانون الأحوال الشخصية وقانون الأسرة
- قانون العمل (القانون 12 لسنة 2003)
- قانون التجارة (القانون 17 لسنة 1999)
- قانون الشركات (القانون 159 لسنة 1981)
- قانون الإيجارات والعقارات
- قانون الضرائب على الدخل (القانون 91 لسنة 2005)
- قانون الملكية الفكرية (القانون 82 لسنة 2002)
- قانون البيئة (القانون 4 لسنة 1994)
- قانون الاستثمار (القانون 72 لسنة 2017)
- الدستور المصري 2014`;

router.get("/anthropic/conversations", async (req, res) => {
  try {
    const result = await db.execute(
      sql`SELECT id, title, created_at FROM conversations ORDER BY created_at DESC`
    );
    res.json(result.rows.map((r: Record<string, unknown>) => ({
      id: r.id,
      title: r.title,
      createdAt: r.created_at,
    })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/anthropic/conversations", async (req, res) => {
  try {
    const { title } = req.body;
    if (!title) return res.status(400).json({ error: "title is required" });
    const result = await db.execute(
      sql`INSERT INTO conversations (title) VALUES (${title}) RETURNING id, title, created_at`
    );
    const row = result.rows[0] as Record<string, unknown>;
    res.status(201).json({ id: row.id, title: row.title, createdAt: row.created_at });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/anthropic/conversations/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const convResult = await db.execute(
      sql`SELECT id, title, created_at FROM conversations WHERE id = ${id}`
    );
    if (!convResult.rows.length) return res.status(404).json({ error: "Not found" });

    const msgResult = await db.execute(
      sql`SELECT id, conversation_id, role, content, created_at FROM ai_messages WHERE conversation_id = ${id} ORDER BY created_at ASC`
    );

    const conv = convResult.rows[0] as Record<string, unknown>;
    res.json({
      id: conv.id,
      title: conv.title,
      createdAt: conv.created_at,
      messages: msgResult.rows.map((m: Record<string, unknown>) => ({
        id: m.id,
        conversationId: m.conversation_id,
        role: m.role,
        content: m.content,
        createdAt: m.created_at,
      })),
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/anthropic/conversations/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.execute(sql`DELETE FROM conversations WHERE id = ${id}`);
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/anthropic/conversations/:id/messages", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const result = await db.execute(
      sql`SELECT id, conversation_id, role, content, created_at FROM ai_messages WHERE conversation_id = ${id} ORDER BY created_at ASC`
    );
    res.json(result.rows.map((m: Record<string, unknown>) => ({
      id: m.id,
      conversationId: m.conversation_id,
      role: m.role,
      content: m.content,
      createdAt: m.created_at,
    })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/anthropic/conversations/:id/messages", async (req, res) => {
  try {
    const convId = parseInt(req.params.id);
    const { content } = req.body;
    if (!content) return res.status(400).json({ error: "content is required" });

    // Save user message
    await db.execute(
      sql`INSERT INTO ai_messages (conversation_id, role, content) VALUES (${convId}, 'user', ${content})`
    );

    // Fetch full conversation history
    const historyResult = await db.execute(
      sql`SELECT role, content FROM ai_messages WHERE conversation_id = ${convId} ORDER BY created_at ASC`
    );

    const chatMessages = historyResult.rows.map((m: Record<string, unknown>) => ({
      role: m.role as "user" | "assistant",
      content: m.content as string,
    }));

    // SSE headers
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    let fullResponse = "";

    const stream = anthropic.messages.stream({
      model: "claude-sonnet-4-6",
      max_tokens: 8192,
      system: SYSTEM_PROMPT,
      messages: chatMessages,
    });

    for await (const event of stream) {
      if (event.type === "content_block_delta" && event.delta.type === "text_delta") {
        fullResponse += event.delta.text;
        res.write(`data: ${JSON.stringify({ content: event.delta.text })}\n\n`);
      }
    }

    // Save assistant message
    await db.execute(
      sql`INSERT INTO ai_messages (conversation_id, role, content) VALUES (${convId}, 'assistant', ${fullResponse})`
    );

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err) {
    req.log.error(err);
    res.write(`data: ${JSON.stringify({ error: "حدث خطأ في المساعد الذكي" })}\n\n`);
    res.end();
  }
});

export default router;
