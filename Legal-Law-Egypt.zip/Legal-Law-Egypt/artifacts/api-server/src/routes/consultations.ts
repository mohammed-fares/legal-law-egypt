import { Router } from "express";
import { db } from "@workspace/db";
import { sql } from "drizzle-orm";

const router = Router();

async function ensureTable() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS consultations (
      id SERIAL PRIMARY KEY,
      lawyer_id INTEGER NOT NULL,
      lawyer_name TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'consultation',
      message TEXT,
      preferred_time TEXT,
      subject TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      created_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);
}

ensureTable().catch(() => {});

router.post("/consultations", async (req, res) => {
  try {
    await ensureTable();
    const { lawyerId, lawyerName, type, message, preferredTime, subject } = req.body;
    if (!lawyerId || !lawyerName || !type) {
      res.status(400).json({ error: "lawyerId, lawyerName, and type are required" });
      return;
    }
    const result = await db.execute(sql`
      INSERT INTO consultations (lawyer_id, lawyer_name, type, message, preferred_time, subject)
      VALUES (${lawyerId}, ${lawyerName}, ${type}, ${message ?? null}, ${preferredTime ?? null}, ${subject ?? null})
      RETURNING id, lawyer_id, lawyer_name, type, status, created_at
    `);
    const row = result.rows[0] as Record<string, unknown>;
    res.status(201).json({
      id: row.id,
      lawyerId: row.lawyer_id,
      lawyerName: row.lawyer_name,
      type: row.type,
      status: row.status,
      createdAt: row.created_at,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/consultations", async (req, res) => {
  try {
    await ensureTable();
    const result = await db.execute(sql`
      SELECT id, lawyer_id, lawyer_name, type, message, status, created_at
      FROM consultations ORDER BY created_at DESC LIMIT 20
    `);
    res.json(result.rows.map((r: Record<string, unknown>) => ({
      id: r.id,
      lawyerId: r.lawyer_id,
      lawyerName: r.lawyer_name,
      type: r.type,
      message: r.message,
      status: r.status,
      createdAt: r.created_at,
    })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
