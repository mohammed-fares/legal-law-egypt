import { Router } from "express";
import { db } from "@workspace/db";
import { casesTable } from "@workspace/db";
import { eq, sql, desc } from "drizzle-orm";

const router = Router();

router.get("/dashboard/stats", async (req, res) => {
  try {
    const [total] = await db.select({ count: sql<number>`count(*)` }).from(casesTable);
    const [active] = await db.select({ count: sql<number>`count(*)` }).from(casesTable).where(eq(casesTable.status, "active"));
    const [completed] = await db.select({ count: sql<number>`count(*)` }).from(casesTable).where(eq(casesTable.analysisStatus, "completed"));
    const [pending] = await db.select({ count: sql<number>`count(*)` }).from(casesTable).where(eq(casesTable.status, "pending"));

    res.json({
      totalCases: Number(total?.count ?? 0),
      activeCases: Number(active?.count ?? 0),
      completedAnalysis: Number(completed?.count ?? 0),
      upcomingSessions: Number(pending?.count ?? 0),
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/dashboard/recent-cases", async (req, res) => {
  try {
    const cases = await db.select().from(casesTable).orderBy(desc(casesTable.id)).limit(5);
    res.json(cases.map((c) => ({
      id: c.id,
      caseNumber: c.caseNumber,
      type: c.type,
      title: c.title,
      description: c.description ?? null,
      court: c.court ?? null,
      courtCaseNumber: c.courtCaseNumber ?? null,
      status: c.status,
      date: c.createdAt.toISOString().split("T")[0],
      analysisStatus: c.analysisStatus,
    })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/dashboard/case-type-counts", async (req, res) => {
  try {
    const counts = await db.select({
      type: casesTable.type,
      count: sql<number>`count(*)`,
    }).from(casesTable).groupBy(casesTable.type);

    res.json(counts.map((r) => ({ type: r.type, count: Number(r.count) })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/dashboard/notifications", async (req, res) => {
  try {
    const analyzedCases = await db
      .select()
      .from(casesTable)
      .where(eq(casesTable.analysisStatus, "completed"))
      .orderBy(desc(casesTable.id))
      .limit(3);

    const activeCases = await db
      .select()
      .from(casesTable)
      .where(eq(casesTable.status, "active"))
      .orderBy(desc(casesTable.id))
      .limit(2);

    const notifications: Array<{
      id: string;
      type: string;
      message: string;
      time: string;
    }> = [];

    analyzedCases.forEach((c, i) => {
      const diffMs = Date.now() - new Date(c.createdAt).getTime();
      const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
      const diffDays = Math.floor(diffHours / 24);
      const timeStr =
        diffDays > 0
          ? `منذ ${diffDays} ${diffDays === 1 ? "يوم" : "أيام"}`
          : diffHours > 0
          ? `منذ ${diffHours} ${diffHours === 1 ? "ساعة" : "ساعات"}`
          : "منذ قليل";

      notifications.push({
        id: `analyzed-${c.id}-${i}`,
        type: "success",
        message: `تم اكتمال تحليل قضية "${c.title}"`,
        time: timeStr,
      });
    });

    activeCases.forEach((c, i) => {
      const diffMs = Date.now() - new Date(c.createdAt).getTime();
      const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
      const diffDays = Math.floor(diffHours / 24);
      const timeStr =
        diffDays > 0
          ? `منذ ${diffDays} ${diffDays === 1 ? "يوم" : "أيام"}`
          : diffHours > 0
          ? `منذ ${diffHours} ${diffHours === 1 ? "ساعة" : "ساعات"}`
          : "منذ قليل";

      notifications.push({
        id: `active-${c.id}-${i}`,
        type: "info",
        message: `القضية "${c.title}" نشطة وتنتظر متابعتك`,
        time: timeStr,
      });
    });

    if (notifications.length === 0) {
      notifications.push({
        id: "empty-1",
        type: "info",
        message: "لا توجد تحديثات حالياً. أضف قضية جديدة للبدء.",
        time: "الآن",
      });
    }

    res.json(notifications.slice(0, 4));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
