import { Router } from "express";
import { db } from "@workspace/db";
import { lawyersTable } from "@workspace/db";
import { eq, like, or } from "drizzle-orm";
import { GetLawyersQueryParams } from "@workspace/api-zod";

const router = Router();

router.get("/lawyers", async (req, res) => {
  try {
    const parsed = GetLawyersQueryParams.safeParse(req.query);
    const params = parsed.success ? parsed.data : {};

    let lawyers;
    if (params.specialty && params.specialty !== "all") {
      lawyers = await db.select().from(lawyersTable).where(eq(lawyersTable.specialty, params.specialty));
    } else {
      lawyers = await db.select().from(lawyersTable);
    }

    if (params.search) {
      const search = params.search.toLowerCase();
      lawyers = lawyers.filter(
        (l) => l.name.toLowerCase().includes(search) || l.specialty.toLowerCase().includes(search)
      );
    }

    res.json(lawyers);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
