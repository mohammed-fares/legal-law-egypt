import React from 'react';
import {
  FileText, Activity, CheckCircle, Calendar, Scale, MoreVertical
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell, Tooltip
} from 'recharts';

const stats = [
  { label: 'إجمالي القضايا', value: 5, icon: FileText, color: '#b45309', bgColor: '#fef3c7' },
  { label: 'القضايا النشطة', value: 3, icon: Activity, color: '#dc6b2f', bgColor: '#ffedd5' },
  { label: 'التحليلات المكتملة', value: 4, icon: CheckCircle, color: '#b45309', bgColor: '#fef3c7' },
  { label: 'الجلسات القادمة', value: 3, icon: Calendar, color: '#dc6b2f', bgColor: '#ffedd5' },
];

const chartData = [
  { name: 'مدني', count: 2 },
  { name: 'جنائي', count: 1 },
  { name: 'تجاري', count: 1 },
  { name: 'عمالي', count: 1 },
];

const recentCases = [
  { id: 1, title: 'قضية تعويض مدني - شركة الأفق', type: 'مدني', court: 'محكمة القاهرة الابتدائية', status: 'نشطة' },
  { id: 2, title: 'نزاع تجاري - عقود توريد', type: 'تجاري', court: 'محكمة الجيزة الاقتصادية', status: 'معلقة' },
  { id: 3, title: 'قضية عمالية - فصل تعسفي', type: 'عمالي', court: 'المحكمة العمالية', status: 'مغلقة' },
];

const notifications = [
  { id: 1, text: 'تم تحديث حالة القضية رقم 452 إلى "نشطة"', time: 'قبل ساعتين', icon: Activity },
  { id: 2, text: 'موعد جلسة جديد للقضية العمالية غداً', time: 'قبل 4 ساعات', icon: Calendar },
  { id: 3, text: 'تم استلام مستندات جديدة في قضية التعويض', time: 'أمس', icon: FileText },
];

export function Warm() {
  return (
    <div 
      dir="rtl" 
      className="min-h-screen p-6 md:p-12 text-[#431407]"
      style={{ 
        fontFamily: "'Cairo', sans-serif", 
        backgroundColor: '#faf7f2',
      }}
    >
      <header className="mb-10">
        <h1 className="text-3xl font-bold" style={{ color: '#b45309' }}>نظرة عامة</h1>
        <p className="text-[#78350f] mt-2 text-lg">مرحباً بك، إليك ملخص نشاطك القانوني اليوم.</p>
      </header>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        {stats.map((stat, idx) => (
          <div 
            key={idx} 
            className="bg-white p-6 rounded-2xl flex flex-col justify-between"
            style={{ boxShadow: '0 10px 25px -5px rgba(180, 83, 9, 0.08), 0 8px 10px -6px rgba(180, 83, 9, 0.04)' }}
          >
            <div className="flex justify-between items-start mb-6">
              <div 
                className="w-14 h-14 rounded-2xl flex items-center justify-center"
                style={{ backgroundColor: stat.bgColor }}
              >
                <stat.icon size={28} style={{ color: stat.color }} />
              </div>
            </div>
            <div>
              <p className="text-[#92400e] font-medium text-lg mb-1">{stat.label}</p>
              <p className="text-4xl font-bold" style={{ color: '#b45309' }}>{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        {/* Main Content Area */}
        <div className="lg:col-span-2 space-y-10">
          
          {/* Chart */}
          <div 
            className="bg-white p-8 rounded-2xl"
            style={{ boxShadow: '0 10px 25px -5px rgba(180, 83, 9, 0.08)' }}
          >
            <h2 className="text-2xl font-bold mb-8" style={{ color: '#b45309' }}>توزيع القضايا حسب النوع</h2>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                  <XAxis 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fill: '#78350f', fontSize: 14, fontFamily: 'Cairo' }}
                    dy={10}
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fill: '#78350f', fontSize: 14, fontFamily: 'Cairo' }}
                  />
                  <Tooltip 
                    cursor={{ fill: '#fef3c7', opacity: 0.5 }}
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 25px -5px rgba(180, 83, 9, 0.1)', fontFamily: 'Cairo', color: '#78350f' }}
                  />
                  <Bar dataKey="count" radius={[8, 8, 8, 8]} barSize={40}>
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#b45309' : '#dc6b2f'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Recent Cases */}
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold" style={{ color: '#b45309' }}>القضايا الأخيرة</h2>
              <button className="text-[#dc6b2f] hover:text-[#b45309] font-medium px-4 py-2 bg-white rounded-xl shadow-sm">
                عرض الكل
              </button>
            </div>
            <div className="space-y-4">
              {recentCases.map((caseItem) => (
                <div 
                  key={caseItem.id} 
                  className="bg-white p-6 rounded-2xl border-r-4 hover:bg-[#fffbf5] transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4"
                  style={{ 
                    borderColor: '#b45309',
                    boxShadow: '0 4px 15px -3px rgba(180, 83, 9, 0.05)'
                  }}
                >
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-full bg-[#fef3c7] flex items-center justify-center shrink-0">
                      <Scale size={24} style={{ color: '#b45309' }} />
                    </div>
                    <div>
                      <h3 className="font-bold text-lg text-[#431407]">{caseItem.title}</h3>
                      <p className="text-[#92400e] mt-1">{caseItem.court}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span 
                      className="px-4 py-1.5 rounded-full text-sm font-medium"
                      style={{ 
                        backgroundColor: '#ffedd5', 
                        color: '#b45309'
                      }}
                    >
                      {caseItem.type}
                    </span>
                    <span 
                      className="px-4 py-1.5 rounded-full text-sm font-medium"
                      style={{ 
                        backgroundColor: caseItem.status === 'نشطة' ? '#dcfce7' : caseItem.status === 'معلقة' ? '#fef9c3' : '#f3f4f6', 
                        color: caseItem.status === 'نشطة' ? '#166534' : caseItem.status === 'معلقة' ? '#854d0e' : '#374151'
                      }}
                    >
                      {caseItem.status}
                    </span>
                    <button className="p-2 text-[#92400e] hover:bg-[#fef3c7] rounded-full transition-colors">
                      <MoreVertical size={20} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-8">
          
          {/* Notifications */}
          <div 
            className="bg-white p-8 rounded-2xl"
            style={{ boxShadow: '0 10px 25px -5px rgba(180, 83, 9, 0.08)' }}
          >
            <h2 className="text-xl font-bold mb-6" style={{ color: '#b45309' }}>التحديثات الأخيرة</h2>
            <div className="space-y-6">
              {notifications.map((note) => (
                <div key={note.id} className="flex gap-4">
                  <div className="w-10 h-10 rounded-full bg-[#ffedd5] flex items-center justify-center shrink-0 mt-1">
                    <note.icon size={18} style={{ color: '#dc6b2f' }} />
                  </div>
                  <div>
                    <p className="text-[#431407] font-medium leading-relaxed">{note.text}</p>
                    <p className="text-[#b45309] text-sm mt-1">{note.time}</p>
                  </div>
                </div>
              ))}
            </div>
            <button className="w-full mt-8 py-3 rounded-xl border border-[#b45309] text-[#b45309] font-medium hover:bg-[#fef3c7] transition-colors">
              عرض كل الإشعارات
            </button>
          </div>

        </div>
      </div>
    </div>
  );
}
