import React from 'react';
import { FileText, Activity, CheckCircle, Calendar, ArrowRight, ChevronLeft } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell, Tooltip } from 'recharts';

export function Minimal() {
  const stats = [
    { label: 'إجمالي القضايا', value: 5, icon: FileText },
    { label: 'قضايا نشطة', value: 3, icon: Activity },
    { label: 'تحليلات مكتملة', value: 4, icon: CheckCircle },
    { label: 'جلسات قادمة', value: 3, icon: Calendar },
  ];

  const chartData = [
    { name: 'مدني', count: 2 },
    { name: 'جنائي', count: 1 },
    { name: 'تجاري', count: 1 },
    { name: 'عمالي', count: 1 },
  ];

  const recentCases = [
    { title: 'نزاع تجاري - شركة الأفق', type: 'تجاري', court: 'المحكمة الاقتصادية', status: 'نشطة' },
    { title: 'دعوى عمالية - أحمد محمد', type: 'عمالي', court: 'المحكمة العمالية', status: 'معلقة' },
    { title: 'قضية تعويضات مدنية', type: 'مدني', court: 'محكمة الاستئناف', status: 'مغلقة' },
  ];

  const notifications = [
    { text: 'تم تحديث حالة القضية رقم 1024', time: 'منذ ساعتين' },
    { text: 'اكتمال تحليل المستندات للقضية العمالية', time: 'منذ 5 ساعات' },
    { text: 'تذكير: جلسة استماع غداً صباحاً', time: 'منذ يوم واحد' },
  ];

  return (
    <div 
      dir="rtl" 
      className="min-h-screen p-8"
      style={{ 
        fontFamily: '"Cairo", sans-serif',
        backgroundColor: '#ffffff',
        color: '#111827'
      }}
    >
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Header */}
        <header className="flex justify-between items-end border-b border-gray-200 pb-6">
          <div>
            <h1 className="text-3xl font-extrabold text-[#111827] tracking-tight mb-2">لوحة القيادة</h1>
            <p className="text-[#6b7280] font-light">موجز الحالة القانونية والنشاط الحالي.</p>
          </div>
          <div className="text-sm text-[#6b7280]">
            {new Date().toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </div>
        </header>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {stats.map((stat, i) => (
            <div 
              key={i} 
              className="bg-[#f8f9fa] border border-[#e5e7eb] p-6 flex flex-col justify-center items-start"
            >
              <span className="text-5xl font-extrabold text-[#4f46e5] mb-4">{stat.value}</span>
              <div className="flex items-center gap-2">
                <stat.icon className="w-4 h-4 text-[#6b7280]" strokeWidth={1.5} />
                <span className="text-[#6b7280] font-medium text-sm">{stat.label}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content Area */}
          <div className="lg:col-span-2 space-y-12">
            
            {/* Chart Section */}
            <section>
              <h2 className="text-xl font-bold text-[#111827] mb-6">القضايا حسب النوع</h2>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                    <XAxis 
                      dataKey="name" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#6b7280', fontSize: 14, fontFamily: 'Cairo' }}
                      dy={10}
                    />
                    <YAxis 
                      hide
                    />
                    <Tooltip 
                      cursor={{ fill: '#f8f9fa' }}
                      contentStyle={{ 
                        backgroundColor: '#ffffff', 
                        border: '1px solid #e5e7eb',
                        borderRadius: 0,
                        fontFamily: 'Cairo',
                        boxShadow: 'none'
                      }}
                    />
                    <Bar dataKey="count" radius={[0, 0, 0, 0]} barSize={40}>
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill="#4f46e5" />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </section>

            {/* Recent Cases */}
            <section>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-[#111827]">القضايا الأخيرة</h2>
                <button className="text-[#4f46e5] text-sm font-medium flex items-center gap-1 hover:underline">
                  عرض الكل <ChevronLeft className="w-4 h-4" />
                </button>
              </div>
              <div className="w-full">
                <table className="w-full text-right border-collapse">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="py-4 font-bold text-[#111827] text-sm w-1/2">القضية</th>
                      <th className="py-4 font-bold text-[#111827] text-sm">المحكمة</th>
                      <th className="py-4 font-bold text-[#111827] text-sm">الحالة</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentCases.map((c, i) => (
                      <tr key={i} className="border-b border-gray-100 last:border-0 hover:bg-[#f8f9fa] transition-colors">
                        <td className="py-4">
                          <div className="font-bold text-[#111827]">{c.title}</div>
                          <div className="text-xs text-[#6b7280] mt-1">{c.type}</div>
                        </td>
                        <td className="py-4 text-[#6b7280] text-sm">{c.court}</td>
                        <td className="py-4">
                          <span className={`text-xs px-2 py-1 bg-[#f8f9fa] border ${
                            c.status === 'نشطة' ? 'border-[#4f46e5] text-[#4f46e5]' : 
                            c.status === 'معلقة' ? 'border-amber-500 text-amber-600' : 
                            'border-gray-300 text-gray-500'
                          }`}>
                            {c.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          </div>

          {/* Sidebar */}
          <div className="space-y-12">
            <section>
              <h2 className="text-xl font-bold text-[#111827] mb-6 border-b border-gray-200 pb-2">التحديثات</h2>
              <div className="space-y-6 pt-2">
                {notifications.map((n, i) => (
                  <div key={i} className="flex flex-col">
                    <span className="text-[#111827] text-sm font-medium leading-relaxed">{n.text}</span>
                    <span className="text-[#6b7280] text-xs mt-2">{n.time}</span>
                  </div>
                ))}
              </div>
              <button className="mt-8 w-full py-3 border border-[#e5e7eb] text-[#111827] text-sm font-bold hover:bg-[#f8f9fa] transition-colors">
                سجل النشاط
              </button>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}
