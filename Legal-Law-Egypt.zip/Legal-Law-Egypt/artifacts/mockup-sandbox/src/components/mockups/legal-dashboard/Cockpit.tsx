import React from "react";
import { 
  FileText, Activity, CheckCircle, Calendar, 
  AlertCircle, Clock, Gavel, TrendingUp, Zap,
  LayoutDashboard, Briefcase, FileSignature, Settings, Bell, Search
} from "lucide-react";
import { 
  BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell, Tooltip 
} from "recharts";

export function Cockpit() {
  // Mock Data
  const stats = [
    { label: "إجمالي القضايا", value: 5, icon: FileText, color: "#f0c040" },
    { label: "قضايا نشطة", value: 3, icon: Activity, color: "#3b82f6" },
    { label: "تحليلات مكتملة", value: 4, icon: CheckCircle, color: "#10b981" },
    { label: "جلسات قادمة", value: 3, icon: Calendar, color: "#8b5cf6" }
  ];

  const chartData = [
    { name: "مدني", count: 2 },
    { name: "جنائي", count: 1 },
    { name: "تجاري", count: 1 },
    { name: "عمالي", count: 1 }
  ];

  const recentCases = [
    { id: "CAS-1042", title: "نزاع تجاري - شركة الأفق", type: "تجاري", court: "المحكمة الاقتصادية", status: "نشطة" },
    { id: "CAS-1043", title: "قضية عمالية - أحمد محمود", type: "عمالي", court: "المحكمة العمالية", status: "معلقة" },
    { id: "CAS-1044", title: "دعوى مدنية - تعويضات", type: "مدني", court: "محكمة شمال القاهرة", status: "مغلقة" }
  ];

  const notifications = [
    { id: 1, text: "تم تحديث موعد الجلسة لقضية رقم CAS-1042", time: "منذ 10 دقائق", icon: Clock },
    { id: 2, text: "اكتمل تحليل مستندات القضية العمالية", time: "منذ ساعتين", icon: CheckCircle },
    { id: 3, text: "تنبيه: اقتراب موعد تقديم المذكرة الختامية", time: "منذ 5 ساعات", icon: AlertCircle }
  ];

  return (
    <div 
      dir="rtl" 
      className="min-h-screen text-slate-300 flex overflow-hidden selection:bg-[#f0c040]/30"
      style={{ 
        backgroundColor: "#080c18", 
        fontFamily: "'Cairo', sans-serif" 
      }}
    >
      {/* Sidebar Simulation - Left aligned in RTL */}
      <aside className="w-16 flex flex-col items-center py-6 gap-8 border-l border-white/5 bg-[#0a0f1d] z-10 shrink-0">
        <div className="text-[#f0c040] shadow-sm rounded-lg p-2" style={{ boxShadow: "0 0 15px rgba(240, 192, 64, 0.4)" }}>
          <Zap size={24} />
        </div>
        <nav className="flex flex-col gap-6">
          {[LayoutDashboard, Briefcase, FileSignature, Gavel, Bell, Settings].map((Icon, i) => (
            <button key={i} className={`p-2 rounded-lg transition-colors ${i === 0 ? "text-[#f0c040] bg-[#f0c040]/10" : "text-slate-500 hover:text-slate-300 hover:bg-white/5"}`}>
              <Icon size={20} />
            </button>
          ))}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-4 flex flex-col h-screen overflow-y-auto">
        {/* Header */}
        <header className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#f0c040] animate-pulse" style={{ boxShadow: "0 0 10px #f0c040" }}></span>
              غرفة العمليات المركزية
            </h1>
            <p className="text-xs text-slate-500 mt-1 uppercase tracking-widest font-mono">SYS.STAT: ONLINE | ENCRYPTED</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
              <input 
                type="text" 
                placeholder="بحث في النظام..." 
                className="bg-[#0f1629] border border-white/10 rounded-md py-1.5 pr-9 pl-3 text-sm focus:outline-none focus:border-[#3b82f6] text-white w-64 placeholder:text-slate-600 transition-colors"
              />
            </div>
            <div className="h-8 w-8 rounded-full bg-[#1e293b] flex items-center justify-center border border-white/10">
              <span className="text-xs font-bold text-white">م.أ</span>
            </div>
          </div>
        </header>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-12 gap-4 flex-1 min-h-0">
          
          {/* Top Row: Stats (Takes full width, 4 cols each) */}
          <div className="col-span-12 grid grid-cols-4 gap-4">
            {stats.map((stat, i) => (
              <div key={i} className="bg-[#0f1629] border border-white/5 rounded-lg p-4 relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-1 h-full" style={{ backgroundColor: stat.color, boxShadow: `0 0 10px ${stat.color}` }}></div>
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-xs text-slate-500 font-medium">{stat.label}</p>
                    <p className="text-3xl font-bold text-white mt-1 font-mono tracking-tighter" style={{ textShadow: `0 0 20px ${stat.color}40` }}>
                      {stat.value.toString().padStart(2, '0')}
                    </p>
                  </div>
                  <div className="p-2 rounded-md bg-white/5" style={{ color: stat.color }}>
                    <stat.icon size={18} />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Middle Row: Chart & Notifications */}
          <div className="col-span-12 lg:col-span-8 bg-[#0f1629] border border-white/5 rounded-lg p-4 flex flex-col">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <TrendingUp size={16} className="text-[#3b82f6]" />
                توزيع القضايا حسب النوع
              </h2>
            </div>
            <div className="flex-1 min-h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <XAxis 
                    dataKey="name" 
                    stroke="#475569" 
                    tick={{ fill: '#94a3b8', fontSize: 12, fontFamily: 'Cairo' }} 
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis 
                    stroke="#475569" 
                    tick={{ fill: '#94a3b8', fontSize: 12, fontFamily: 'monospace' }} 
                    axisLine={false}
                    tickLine={false}
                    tickCount={4}
                  />
                  <Tooltip 
                    cursor={{ fill: 'rgba(255,255,255,0.02)' }}
                    contentStyle={{ backgroundColor: '#0f1629', borderColor: 'rgba(255,255,255,0.1)', color: '#fff', borderRadius: '4px', fontSize: '12px' }}
                    itemStyle={{ color: '#f0c040', fontFamily: 'monospace' }}
                  />
                  <Bar dataKey="count" radius={[2, 2, 0, 0]} maxBarSize={40}>
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill="#f0c040" />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="col-span-12 lg:col-span-4 bg-[#0f1629] border border-white/5 rounded-lg p-4 flex flex-col">
             <div className="flex justify-between items-center mb-4">
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Bell size={16} className="text-[#f0c040]" />
                سجل التحديثات
              </h2>
            </div>
            <div className="flex flex-col gap-3 flex-1 overflow-y-auto pr-1">
              {notifications.map(note => (
                <div key={note.id} className="flex gap-3 items-start border-b border-white/5 pb-3 last:border-0 last:pb-0">
                  <div className="mt-0.5 text-slate-400 bg-white/5 p-1.5 rounded">
                    <note.icon size={14} />
                  </div>
                  <div className="flex-1">
                    <p className="text-xs text-slate-300 leading-relaxed">{note.text}</p>
                    <p className="text-[10px] text-slate-500 mt-1 font-mono">{note.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Bottom Row: Recent Cases */}
          <div className="col-span-12 bg-[#0f1629] border border-white/5 rounded-lg p-4">
             <div className="flex justify-between items-center mb-4">
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Briefcase size={16} className="text-[#10b981]" />
                القضايا النشطة حديثاً
              </h2>
              <button className="text-xs text-[#3b82f6] hover:text-[#60a5fa] transition-colors">عرض الكل</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-right border-collapse">
                <thead>
                  <tr className="border-b border-white/10 text-xs text-slate-500 uppercase tracking-wider">
                    <th className="pb-2 font-medium">المعرف</th>
                    <th className="pb-2 font-medium">عنوان القضية</th>
                    <th className="pb-2 font-medium">النوع</th>
                    <th className="pb-2 font-medium">المحكمة</th>
                    <th className="pb-2 font-medium">الحالة</th>
                  </tr>
                </thead>
                <tbody className="text-sm">
                  {recentCases.map((c, i) => (
                    <tr key={c.id} className="border-b border-white/5 hover:bg-white/[0.02] transition-colors">
                      <td className="py-3 font-mono text-xs text-slate-400">{c.id}</td>
                      <td className="py-3 font-medium text-slate-200">{c.title}</td>
                      <td className="py-3">
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 text-slate-300 border border-white/10">{c.type}</span>
                      </td>
                      <td className="py-3 text-slate-400 text-xs">{c.court}</td>
                      <td className="py-3">
                        <span className={`text-[10px] px-2 py-0.5 rounded-full flex items-center gap-1.5 w-max
                          ${c.status === 'نشطة' ? 'text-[#3b82f6] bg-[#3b82f6]/10 border border-[#3b82f6]/20' : 
                            c.status === 'معلقة' ? 'text-[#f0c040] bg-[#f0c040]/10 border border-[#f0c040]/20' : 
                            'text-slate-400 bg-white/5 border border-white/10'}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${c.status === 'نشطة' ? 'bg-[#3b82f6] animate-pulse' : c.status === 'معلقة' ? 'bg-[#f0c040]' : 'bg-slate-400'}`}></span>
                          {c.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
}